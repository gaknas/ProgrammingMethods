﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Task4
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void btnMin_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnMaxmin_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LoadHolidays()
        {
            StreamReader sr = new StreamReader("E:\\Методы программирования\\Задание 4\\Task4\\holidays.txt");
            string[] info = sr.ReadToEnd().Split(';');
            this.mcRight.RemoveAllBoldedDates();
            foreach (string date in info)
            {
                this.mcRight.AddBoldedDate(Convert.ToDateTime(date));
            }
            for (DateTime i = Convert.ToDateTime("01.01.2024"); i <= Convert.ToDateTime("31.12.2024"); i = i.AddDays(1))
            {
                if (i.DayOfWeek.ToString() == "Saturday" || i.DayOfWeek.ToString() == "Sunday") this.mcRight.AddBoldedDate(i);
            }
            this.mcRight.UpdateBoldedDates();
            sr.Close();
            sr = new StreamReader("E:\\Методы программирования\\Задание 4\\Task4\\writtendates.txt");
            info = sr.ReadToEnd().Split(new char[] {';'}, StringSplitOptions.RemoveEmptyEntries);
            this.mcLeft.RemoveAllBoldedDates();
            foreach (string date in info)
            {
                this.mcLeft.AddBoldedDate(Convert.ToDateTime(date));
            }
            this.mcLeft.UpdateBoldedDates();
            sr.Close();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader("E:\\Методы программирования\\Задание 4\\Task4\\helpinfo.txt");
            string[] info = sr.ReadToEnd().Split(';');
            sr.Close();
            this.ttHelp.SetToolTip(this.mcLeft, info[0]);
            this.ttHelp.SetToolTip(this.mcRight, info[1]);
            this.ttHelp.SetToolTip(this.btnClose, info[2]);
            this.ttHelp.SetToolTip(this.btnMin, info[3]);
            this.ttHelp.SetToolTip(this.btnMaxmin, info[4]);
            this.ttHelp.SetToolTip(this.btnWritedate, info[5]);
            this.ttHelp.SetToolTip(this.btnClear, info[6]);
            this.LoadHolidays();
        }

        private void btnWritedate_Click(object sender, EventArgs e)
        {
            DateTime selected = this.mcLeft.SelectionStart;
            StreamWriter sw = new StreamWriter("E:\\Методы программирования\\Задание 4\\Task4\\writtendates.txt", true);
            sw.Write(selected.ToString("d"));
            sw.Write(';');
            sw.Close();
            this.mcLeft.AddBoldedDate(selected);
            this.mcLeft.UpdateBoldedDates();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            StreamWriter sw = new StreamWriter("E:\\Методы программирования\\Задание 4\\Task4\\writtendates.txt");
            sw.Close();
            this.mcLeft.RemoveAllBoldedDates();
            this.mcLeft.UpdateBoldedDates();
        }
    }
}
