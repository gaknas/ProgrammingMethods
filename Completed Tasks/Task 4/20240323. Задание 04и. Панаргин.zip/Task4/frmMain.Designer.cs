﻿
namespace Task4
{
    partial class frmMain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.mcLeft = new System.Windows.Forms.MonthCalendar();
            this.mcRight = new System.Windows.Forms.MonthCalendar();
            this.btnMin = new System.Windows.Forms.Button();
            this.btnMaxmin = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.ttHelp = new System.Windows.Forms.ToolTip(this.components);
            this.btnWritedate = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // mcLeft
            // 
            this.mcLeft.Location = new System.Drawing.Point(18, 18);
            this.mcLeft.Name = "mcLeft";
            this.mcLeft.TabIndex = 0;
            // 
            // mcRight
            // 
            this.mcRight.Location = new System.Drawing.Point(200, 18);
            this.mcRight.Name = "mcRight";
            this.mcRight.TabIndex = 1;
            // 
            // btnMin
            // 
            this.btnMin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMin.FlatAppearance.BorderSize = 0;
            this.btnMin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMin.Image = ((System.Drawing.Image)(resources.GetObject("btnMin.Image")));
            this.btnMin.Location = new System.Drawing.Point(686, 408);
            this.btnMin.Name = "btnMin";
            this.btnMin.Size = new System.Drawing.Size(30, 30);
            this.btnMin.TabIndex = 3;
            this.btnMin.UseVisualStyleBackColor = true;
            this.btnMin.Click += new System.EventHandler(this.btnMin_Click);
            // 
            // btnMaxmin
            // 
            this.btnMaxmin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMaxmin.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnMaxmin.FlatAppearance.BorderSize = 0;
            this.btnMaxmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMaxmin.Image = ((System.Drawing.Image)(resources.GetObject("btnMaxmin.Image")));
            this.btnMaxmin.Location = new System.Drawing.Point(722, 408);
            this.btnMaxmin.Name = "btnMaxmin";
            this.btnMaxmin.Size = new System.Drawing.Size(30, 30);
            this.btnMaxmin.TabIndex = 4;
            this.btnMaxmin.UseVisualStyleBackColor = true;
            this.btnMaxmin.Click += new System.EventHandler(this.btnMaxmin_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.SystemColors.Control;
            this.btnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnClose.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(758, 408);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(30, 30);
            this.btnClose.TabIndex = 5;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // ttHelp
            // 
            this.ttHelp.AutoPopDelay = 5000;
            this.ttHelp.InitialDelay = 500;
            this.ttHelp.ReshowDelay = 100;
            // 
            // btnWritedate
            // 
            this.btnWritedate.Location = new System.Drawing.Point(18, 192);
            this.btnWritedate.Name = "btnWritedate";
            this.btnWritedate.Size = new System.Drawing.Size(164, 57);
            this.btnWritedate.TabIndex = 6;
            this.btnWritedate.Text = "Записать дату";
            this.btnWritedate.UseVisualStyleBackColor = true;
            this.btnWritedate.Click += new System.EventHandler(this.btnWritedate_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(18, 255);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(164, 57);
            this.btnClear.TabIndex = 7;
            this.btnClear.Text = "Очистить файл";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnWritedate);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnMaxmin);
            this.Controls.Add(this.btnMin);
            this.Controls.Add(this.mcRight);
            this.Controls.Add(this.mcLeft);
            this.Name = "frmMain";
            this.Text = "Задание №2 выполнил: Панаргин Владислав Максимович; Номер варианта: 5; Дата выпол" +
    "нения: 23/03/2024";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MonthCalendar mcLeft;
        private System.Windows.Forms.MonthCalendar mcRight;
        private System.Windows.Forms.Button btnMin;
        private System.Windows.Forms.Button btnMaxmin;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ToolTip ttHelp;
        private System.Windows.Forms.Button btnWritedate;
        private System.Windows.Forms.Button btnClear;
    }
}

