﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms.DataVisualization.Charting;

namespace Coursework
{
    public partial class frmStat : Form
    {
        private string afilename;
        public frmStat(string filename)
        {
            this.afilename = filename;
            InitializeComponent();
        }

        private void btnSoau_Click(object sender, EventArgs e)
        {
            string[] files = Directory.GetFiles(Application.StartupPath + "\\temp");
            Dictionary<string, int> soauth = new Dictionary<string, int>();
            foreach (string filename in files) 
            {
                List<string> authors = new List<string>();
                StreamReader sr = new StreamReader(filename);
                string temp;
                string autst;
                string[] atemp;
                int counter = 0;
                while ((temp = sr.ReadLine()) != null)
                {
                    autst = temp.Remove(temp.Length - 1).Split('!')[5];
                    if (autst == "") { }
                    else
                    {
                        atemp = autst.Replace(" ", string.Empty).Split(',');
                        foreach (string author in atemp)
                        {
                            if (!(authors.Contains(author))) authors.Add(author);
                        }
                    }
                }
                foreach (string author in authors) counter++;
                string name = Regex.Match(filename, "\\(\\w+\\)").Value.Replace("(", string.Empty).Replace(")", string.Empty);
                soauth[name] = counter;
                sr.Close();
            }
            foreach (KeyValuePair<string, int> author in soauth)
            {
                Console.WriteLine($"Author: {author.Key}, Soauthors: {author.Value.ToString()}");
            }
            this.chrtStat.Series.Clear();
            this.chrtStat.Titles.Clear();
            this.chrtStat.Titles.Add("Количество уникальных соавторов");
            foreach (KeyValuePair<string, int> author in soauth)
            {
                Series series = this.chrtStat.Series.Add(author.Key);
                series.Points.Add(author.Value);
            }
        }

        private void btnPubl_Click(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader(this.afilename);
            string temp;
            string pub, year;
            Dictionary<string, int> py = new Dictionary<string, int>();
            while ((temp = sr.ReadLine()) != null)
            {
                pub = temp.Remove(temp.Length - 1).Split('!')[3];
                year = Regex.Match(pub, "20[0-2]\\d").Value;
                if (year == "") year = "NONE";
                if (py.ContainsKey(year)) py[year]++;
                else py[year] = 1;
            }
            foreach (KeyValuePair<string, int> author in py)
            {
                Console.WriteLine($"Year: {author.Key}, Count: {author.Value.ToString()}");
            }
            this.chrtStat.Series.Clear();
            this.chrtStat.Titles.Clear();
            this.chrtStat.Titles.Add("Количество публикаций за год");
            foreach (KeyValuePair<string, int> author in py)
            {
                Series series = this.chrtStat.Series.Add(author.Key);
                series.Points.Add(author.Value);
            }
            sr.Close();
        }

        private void btnVol_Click(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader(this.afilename);
            string temp;
            string stc;
            Dictionary<string, int> volume = new Dictionary<string, int>();
            while ((temp = sr.ReadLine()) != null)
            {
                stc = temp.Remove(temp.Length - 1).Split('!')[4];
                if (stc == "") stc = "NONE";
                if (volume.ContainsKey(stc)) volume[stc]++;
                else volume[stc] = 1;
            }
            foreach (KeyValuePair<string, int> author in volume)
            {
                Console.WriteLine($"STC: {author.Key}, Count: {author.Value.ToString()}");
            }
            this.chrtStat.Series.Clear();
            this.chrtStat.Titles.Clear();
            this.chrtStat.Titles.Add("Количество работ различного объема");
            foreach (KeyValuePair<string, int> author in volume)
            {
                Series series = this.chrtStat.Series.Add(author.Key);
                series.Points.Add(author.Value);
            }
            sr.Close();
        }
    }
}
