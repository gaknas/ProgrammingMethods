﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Word = Microsoft.Office.Interop.Word;
using Excel = Microsoft.Office.Interop.Excel;

namespace Coursework
{
    public partial class frmMain : Form
    {
        private Word.Application wordapp;
        private Word.Document wd;
        string[] files;
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            files = Directory.GetFiles(Application.StartupPath+"\\works");
            string[] temp;
            foreach (string file in files)
            {
                temp = file.Split('\\');
                Console.WriteLine(file);
                this.cmbFiles.Items.Add(temp[temp.Length - 1]);
            }
            this.cmbFiles.SelectedIndex = 0;
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            frmPreview fp = new frmPreview(Application.StartupPath + "\\temp\\" + ChngExtension(this.cmbFiles.SelectedItem.ToString(), ".csv"));
            fp.Show();
        }

        private void btnCSV_Click(object sender, EventArgs e)
        {
            wordapp = new Word.Application();
            wd = wordapp.Documents.Open(this.files[this.cmbFiles.SelectedIndex], ReadOnly:true);
            StreamWriter sw = new StreamWriter(Application.StartupPath + "\\temp\\" + ChngExtension(this.cmbFiles.SelectedItem.ToString(), ".csv"));
            Word.Table wt = wd.Tables[1];
            string temp;
            foreach (Word.Row row in wt.Rows)
            {
                foreach (Word.Cell cl in row.Cells)
                {
                    temp = cl.Range.Text;
                    temp = temp.Replace("\a", string.Empty).Replace("\n", string.Empty).Remove(temp.Length-2);
                    Console.WriteLine(temp);
                    sw.Write(temp);
                    sw.Write("!");
                }
                Console.WriteLine("N");
                sw.Write("\n");
            }
            sw.Close();
            wordapp.Quit();
        }

        public string ChngExtension(string filename, string ext)
        {
            string[] temp = filename.Split('.');
            return temp[0] + ext;
        }

        private void btnExcel_Click(object sender, EventArgs e)
        {
            Excel.Application exapp = new Excel.Application();
            exapp.Workbooks.Add();
            Excel.Worksheet workSheet = (Excel.Worksheet)exapp.ActiveSheet;
            StreamReader sr = new StreamReader(Application.StartupPath + "\\temp\\" + ChngExtension(this.cmbFiles.SelectedItem.ToString(), ".csv"));
            string temp;
            string[] atemp;
            int counter1 = 1;
            int counter2 = 1;
            string[] top = { "№", "Название", "Печатный или на правах рукописи", "Издательство, журнал (название, год, номер) номер авторского свидетельства", "Количество печатных листов или страниц", "Фамилия соавторов" };
            foreach (string line in top)
            {
                workSheet.Cells[counter1, counter2] = line;
                counter2++;
            }
            counter1++;
            while ((temp = sr.ReadLine()) != null)
            {
                atemp = temp.Remove(temp.Length - 1).Split('!');
                counter2 = 1;
                foreach (string line in atemp)
                {
                    workSheet.Cells[counter1, counter2] = line;
                    counter2++;
                }
                counter1++;
            }
            sr.Close();
            exapp.ActiveWorkbook.SaveAs(Application.StartupPath + "\\output\\" + ChngExtension(this.cmbFiles.SelectedItem.ToString(), ".xlsx"));
            exapp.Quit();
        }

        private void btnWord_Click(object sender, EventArgs e)
        {
            wordapp = new Word.Application();
            wd = wordapp.Documents.Add();
            Word.Paragraph wp = wd.Paragraphs[1];
            Word.Table wt = wd.Tables.Add(wp.Range, 1, 6);
            wt.set_Style("Сетка таблицы");
            StreamReader sr = new StreamReader(Application.StartupPath + "\\temp\\" + ChngExtension(this.cmbFiles.SelectedItem.ToString(), ".csv"));
            int counter1 = 1;
            int counter2 = 1;
            string temp;
            string[] atemp;
            string[] top = { "№", "Название", "Печатный или на правах рукописи", "Издательство, журнал (название, год, номер) номер авторского свидетельства", "Количество печатных листов или страниц", "Фамилия соавторов" };
            foreach (string line in top)
            {
                wt.Cell(1, counter2).Range.Text = line;
                counter2++;
            }
            counter1++;
            while ((temp = sr.ReadLine()) != null)
            {
                atemp = temp.Remove(temp.Length - 1).Split('!');
                counter2 = 1;
                wt.Rows.Add();
                foreach (string line in atemp)
                {
                    wt.Cell(counter1, counter2).Range.Text = line;
                    counter2++;
                }
                counter1++;
            }
            sr.Close();
            wd.SaveAs2(Application.StartupPath + "\\output\\" + this.cmbFiles.SelectedItem.ToString());
            wordapp.Quit();
        }

        private void btnStat_Click(object sender, EventArgs e)
        {
            frmStat fs = new frmStat(Application.StartupPath + "\\temp\\" + ChngExtension(this.cmbFiles.SelectedItem.ToString(), ".csv"));
            fs.Show();
        }
    }
}
