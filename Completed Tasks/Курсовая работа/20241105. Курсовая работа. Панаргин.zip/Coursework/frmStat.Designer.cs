﻿
namespace Coursework
{
    partial class frmStat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            this.chrtStat = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnSoau = new System.Windows.Forms.Button();
            this.btnPubl = new System.Windows.Forms.Button();
            this.btnVol = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.chrtStat)).BeginInit();
            this.SuspendLayout();
            // 
            // chrtStat
            // 
            chartArea1.Name = "ChartArea1";
            this.chrtStat.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chrtStat.Legends.Add(legend1);
            this.chrtStat.Location = new System.Drawing.Point(12, 12);
            this.chrtStat.Name = "chrtStat";
            this.chrtStat.Size = new System.Drawing.Size(481, 392);
            this.chrtStat.TabIndex = 0;
            this.chrtStat.Text = "chart";
            // 
            // btnSoau
            // 
            this.btnSoau.Location = new System.Drawing.Point(555, 12);
            this.btnSoau.Name = "btnSoau";
            this.btnSoau.Size = new System.Drawing.Size(199, 23);
            this.btnSoau.TabIndex = 1;
            this.btnSoau.Text = "Уникальные соавторы";
            this.btnSoau.UseVisualStyleBackColor = true;
            this.btnSoau.Click += new System.EventHandler(this.btnSoau_Click);
            // 
            // btnPubl
            // 
            this.btnPubl.Location = new System.Drawing.Point(555, 41);
            this.btnPubl.Name = "btnPubl";
            this.btnPubl.Size = new System.Drawing.Size(199, 23);
            this.btnPubl.TabIndex = 2;
            this.btnPubl.Text = "Количество публикаций по годам";
            this.btnPubl.UseVisualStyleBackColor = true;
            this.btnPubl.Click += new System.EventHandler(this.btnPubl_Click);
            // 
            // btnVol
            // 
            this.btnVol.Location = new System.Drawing.Point(555, 70);
            this.btnVol.Name = "btnVol";
            this.btnVol.Size = new System.Drawing.Size(199, 23);
            this.btnVol.TabIndex = 3;
            this.btnVol.Text = "Объем работ";
            this.btnVol.UseVisualStyleBackColor = true;
            this.btnVol.Click += new System.EventHandler(this.btnVol_Click);
            // 
            // frmStat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnVol);
            this.Controls.Add(this.btnPubl);
            this.Controls.Add(this.btnSoau);
            this.Controls.Add(this.chrtStat);
            this.Name = "frmStat";
            this.Text = "frmStat";
            ((System.ComponentModel.ISupportInitialize)(this.chrtStat)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chrtStat;
        private System.Windows.Forms.Button btnSoau;
        private System.Windows.Forms.Button btnPubl;
        private System.Windows.Forms.Button btnVol;
    }
}