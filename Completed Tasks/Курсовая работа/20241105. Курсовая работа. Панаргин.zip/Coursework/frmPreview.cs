﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Coursework
{
    public partial class frmPreview : Form
    {
        private string filename;
        public frmPreview(string filename)
        {
            this.filename = filename;
            InitializeComponent();
        }

        private void frmPreview_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            this.dgwPreview.ColumnCount = 6;
            this.dgwPreview.Columns[0].HeaderText = "№";
            this.dgwPreview.Columns[0].Width = 30;
            this.dgwPreview.Columns[1].HeaderText = "Название";
            this.dgwPreview.Columns[1].Width = 500;
            this.dgwPreview.Columns[2].HeaderText = "Печатный или на правах рукописи";
            this.dgwPreview.Columns[3].HeaderText = "Издательство, журнал (название, год, номер) номер авторского свидетельства";
            this.dgwPreview.Columns[3].Width = 500;
            this.dgwPreview.Columns[4].HeaderText = "Количество печатных листов или страниц";
            this.dgwPreview.Columns[4].Width = 50;
            this.dgwPreview.Columns[5].HeaderText = "Фамилия соавторов";
            this.dgwPreview.Columns[5].Width = 200;
            StreamReader sr = new StreamReader(this.filename);
            string temp;
            while ((temp = sr.ReadLine()) != null)
            {
                this.dgwPreview.Rows.Add(temp.Remove(temp.Length-1).Split('!'));
            }
            sr.Close();
        }
    }
}
