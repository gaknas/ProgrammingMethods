﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Task6
{
    public partial class frmPreview : Form
    {
        public frmPreview()
        {
            InitializeComponent();
        }

        private void frmPreview_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            this.dgwPrewiew.ColumnCount = 9;
            this.dgwPrewiew.Columns[0].HeaderText = "Дата составления";
            this.dgwPrewiew.Columns[0].Width = 150;
            this.dgwPrewiew.Columns[1].HeaderText = "Код вида операции";
            this.dgwPrewiew.Columns[1].Width = 150;
            this.dgwPrewiew.Columns[2].HeaderText = "Отправитель";
            this.dgwPrewiew.Columns[2].Width = 200;
            this.dgwPrewiew.Columns[3].Width = 200;
            this.dgwPrewiew.Columns[4].HeaderText = "Получатель";
            this.dgwPrewiew.Columns[4].Width = 200;
            this.dgwPrewiew.Columns[5].Width = 200;
            this.dgwPrewiew.Columns[6].HeaderText = "Ответственный за поставку";
            this.dgwPrewiew.Columns[6].Width = 200;
            this.dgwPrewiew.Columns[7].Width = 200;
            this.dgwPrewiew.Columns[8].Width = 150;
            this.dgwPrewiew.Rows.Add("", "", "структурное подразделение", "вид деятельности", "структурное подразделение", "вид деятельности", "структурное подразделение", "вид деятельности", "код исполнителя");
            List<Line> existingRecords = new List<Line> { };
            string tempStr;
            StreamReader sr = new StreamReader(Application.StartupPath + "\\DocInfo.txt");
            while ((tempStr = sr.ReadLine()) != null)
            {
                existingRecords.Add(new Line(tempStr));
            }
            sr.Close();
            foreach (Line line in existingRecords)
            {
                this.dgwPrewiew.Rows.Add(line.compilationDate.ToString("d"), line.operationCode.ToString(), line.sender.division, line.sender.activity, line.receiver.division, line.receiver.activity, line.provider.division, line.provider.activity, line.provider.executorCode.ToString());
            }
        }
    }
}
