﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;

namespace Task6
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        public void CreateFile(ref Excel.Application exapp)
        {
            Excel.Worksheet workSheet = (Excel.Worksheet)exapp.ActiveSheet;
            workSheet.Range["B2"].Value = "Дата составления";
            workSheet.Columns[2].ColumnWidth = 20f;
            workSheet.Range["B2:B3"].Merge();
            workSheet.Range["B2:B3"].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDouble;
            workSheet.Range["C2"].Value = "Код вида операции";
            workSheet.Columns[3].ColumnWidth = 20f;
            workSheet.Range["C2:C3"].Merge();
            workSheet.Range["C2:C3"].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDouble;
            workSheet.Range["D2"].Value = "Отправитель";
            workSheet.Range["D2:E2"].Merge();
            workSheet.Range["D2:D3"].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDouble;
            workSheet.Range["D3"].Value = "структурное подразделение";
            workSheet.Columns[4].ColumnWidth = 30f;
            workSheet.Range["E3"].Value = "вид деятельности";
            workSheet.Range["E3"].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
            workSheet.Range["E3"].Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 2;
            workSheet.Columns[5].ColumnWidth = 30f;
            workSheet.Range["F2"].Value = "Получатель";
            workSheet.Range["F2:F3"].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDouble;
            workSheet.Range["F2:G2"].Merge();
            workSheet.Range["F3"].Value = "структурное подразделение";
            workSheet.Columns[6].ColumnWidth = 30f;
            workSheet.Range["G3"].Value = "вид деятельности";
            workSheet.Range["G3"].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
            workSheet.Range["G3"].Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 2;
            workSheet.Columns[7].ColumnWidth = 30f;
            workSheet.Range["H2"].Value = "Ответственный за поставку";
            workSheet.Range["H2:J2"].Merge();
            workSheet.Range["H2:H3"].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDouble;
            workSheet.Range["H3"].Value = "структурное подразделение";
            workSheet.Columns[8].ColumnWidth = 30f;
            workSheet.Range["I3"].Value = "вид деятельности";
            workSheet.Range["I3"].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
            workSheet.Range["I3"].Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 2;
            workSheet.Columns[9].ColumnWidth = 30f;
            workSheet.Range["J3"].Value = "код исполнителя";
            workSheet.Range["J3"].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
            workSheet.Range["J3"].Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 2;
            workSheet.Columns[10].ColumnWidth = 20f;
            workSheet.Range["K2:K3"].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDouble;
            workSheet.Range["B2:J2"].Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle = Excel.XlLineStyle.xlDouble;
            workSheet.Range["D2:J2"].Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
            workSheet.Range["D2:J2"].Borders[Excel.XlBordersIndex.xlEdgeBottom].Weight = 2;
            workSheet.Range["B2:J3"].HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            workSheet.Range["B2:J3"].VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
            exapp.ActiveWorkbook.SaveAs(Application.StartupPath + "\\TST.xlsx");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void btnUnload_Click(object sender, EventArgs e)
        {
            Excel.Application exapp = new Excel.Application();
            exapp.Workbooks.Add();
            this.CreateFile(ref exapp);
            exapp.Quit();
        }

        private void btnFill_Click(object sender, EventArgs e)
        {
            List<Line> existingRecords = new List<Line> { };
            string tempStr;
            StreamReader sr = new StreamReader(Application.StartupPath + "\\DocInfo.txt");
            while ((tempStr = sr.ReadLine()) != null)
            {
                existingRecords.Add(new Line(tempStr));
            }
            sr.Close();
            Excel.Application exapp = new Excel.Application();
            if (!(File.Exists(Application.StartupPath + "\\TST.xlsx")))
            {
                exapp.Workbooks.Add();
                this.CreateFile(ref exapp);
            }
            else 
            {
                exapp.Workbooks.Open(Application.StartupPath + "\\TST.xlsx");
            }
            Excel.Worksheet workSheet = (Excel.Worksheet)exapp.ActiveSheet;
            int counter = 1;
            int deltar = 3;
            int deltac = 1;
            foreach (Line line in existingRecords) 
            {
                workSheet.Cells[counter + deltar, 1 + deltac] = line.compilationDate.ToString("d");
                workSheet.Cells[counter + deltar, 1 + deltac].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDouble;
                workSheet.Cells[counter + deltar, 2 + deltac] = line.operationCode.ToString();
                workSheet.Cells[counter + deltar, 2 + deltac].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDouble;
                workSheet.Cells[counter + deltar, 3 + deltac] = line.sender.division;
                workSheet.Cells[counter + deltar, 4 + deltac] = line.sender.activity;
                workSheet.Cells[counter + deltar, 4 + deltac].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                workSheet.Cells[counter + deltar, 4 + deltac].Borders[Excel.XlBordersIndex.xlEdgeTop].Weight = 2;
                workSheet.Cells[counter + deltar, 3 + deltac].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDouble;
                workSheet.Cells[counter + deltar, 5 + deltac] = line.receiver.division;
                workSheet.Cells[counter + deltar, 6 + deltac] = line.receiver.activity;
                workSheet.Cells[counter + deltar, 6 + deltac].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                workSheet.Cells[counter + deltar, 6 + deltac].Borders[Excel.XlBordersIndex.xlEdgeTop].Weight = 2;
                workSheet.Cells[counter + deltar, 5 + deltac].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDouble;
                workSheet.Cells[counter + deltar, 7 + deltac] = line.provider.division;
                workSheet.Cells[counter + deltar, 8 + deltac] = line.provider.activity;
                workSheet.Cells[counter + deltar, 8 + deltac].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                workSheet.Cells[counter + deltar, 8 + deltac].Borders[Excel.XlBordersIndex.xlEdgeTop].Weight = 2;
                workSheet.Cells[counter + deltar, 9 + deltac] = line.provider.executorCode.ToString();
                workSheet.Cells[counter + deltar, 9 + deltac].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlContinuous;
                workSheet.Cells[counter + deltar, 9 + deltac].Borders[Excel.XlBordersIndex.xlEdgeTop].Weight = 2;
                workSheet.Cells[counter + deltar, 7 + deltac].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDouble;
                workSheet.Cells[counter + deltar, 10 + deltac].Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = Excel.XlLineStyle.xlDouble;
                Excel.Range c1 = workSheet.Cells[counter + deltar, 1 + deltac];
                Excel.Range c2 = workSheet.Cells[counter + deltar, 9 + deltac];
                workSheet.get_Range(c1, c2).Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle = Excel.XlLineStyle.xlContinuous;
                workSheet.get_Range(c1, c2).Borders[Excel.XlBordersIndex.xlEdgeTop].Weight = 4;
                workSheet.get_Range(c1, c2).Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
                workSheet.get_Range(c1, c2).Borders[Excel.XlBordersIndex.xlEdgeBottom].Weight = 4;
                workSheet.get_Range(c1, c2).HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                workSheet.get_Range(c1, c2).VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
                counter++;
            }
            exapp.ActiveWorkbook.Save();
            exapp.Quit();
        }

        private void btnPreview_Click(object sender, EventArgs e)
        {
            frmPreview preview = new frmPreview();
            preview.Show();
        }
    }

    public class Party 
    {
        public Party(string partyInfo) 
        {
            string[] strParty = partyInfo.Split(';');
            this.division = strParty[0];
            this.activity = strParty[1];
        }
        public string division { get; set; }
        public string activity { get; set; }
    }

    public class Sender : Party 
    {
        public Sender(string senderInfo)
            : base(senderInfo) { }
    }
    public class Receiver : Party 
    {
        public Receiver(string receiverInfo)
            : base(receiverInfo) { }
    }
    public class Provider : Party 
    {
        public Provider(string providerInfo)
            : base(providerInfo)
        {
            string[] strProvider = providerInfo.Split(';');
            this.executorCode = Convert.ToInt32(strProvider[2]);
        }
        public int executorCode { get; set; }
    }
    public class Line 
    {
        public Line(string lineInfo) 
        {
            string[] temp = lineInfo.Split('!');
            string[] strLine = temp[0].Split(';');
            this.compilationDate = Convert.ToDateTime(strLine[0]);
            this.operationCode = Convert.ToInt32(strLine[1]);
            this.sender = new Sender(temp[1]);
            this.receiver = new Receiver(temp[2]);
            this.provider = new Provider(temp[3]);
        }
        public DateTime compilationDate { get; set; }
        public int operationCode { get; set; }
        public Sender sender { get; set; }
        public Receiver receiver { get; set; }
        public Provider provider { get; set; }
    }
}
