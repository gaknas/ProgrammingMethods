﻿
namespace Task2
{
    partial class frmMain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.btnClose = new System.Windows.Forms.Button();
            this.btnMaxmin = new System.Windows.Forms.Button();
            this.btnMin = new System.Windows.Forms.Button();
            this.pbDraw = new System.Windows.Forms.PictureBox();
            this.btnCircle = new System.Windows.Forms.Button();
            this.btnIsotri = new System.Windows.Forms.Button();
            this.btnRhomb = new System.Windows.Forms.Button();
            this.btnRighttri = new System.Windows.Forms.Button();
            this.btnEllipse = new System.Windows.Forms.Button();
            this.btnSquare = new System.Windows.Forms.Button();
            this.btnParallel = new System.Windows.Forms.Button();
            this.btnAim = new System.Windows.Forms.Button();
            this.btnEquiltri = new System.Windows.Forms.Button();
            this.btnRectangle = new System.Windows.Forms.Button();
            this.btnRing = new System.Windows.Forms.Button();
            this.btnTrapezoid = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbDraw)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.SystemColors.Control;
            this.btnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnClose.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(758, 408);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(30, 30);
            this.btnClose.TabIndex = 0;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Visible = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnMaxmin
            // 
            this.btnMaxmin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMaxmin.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnMaxmin.FlatAppearance.BorderSize = 0;
            this.btnMaxmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMaxmin.Image = ((System.Drawing.Image)(resources.GetObject("btnMaxmin.Image")));
            this.btnMaxmin.Location = new System.Drawing.Point(722, 408);
            this.btnMaxmin.Name = "btnMaxmin";
            this.btnMaxmin.Size = new System.Drawing.Size(30, 30);
            this.btnMaxmin.TabIndex = 1;
            this.btnMaxmin.UseVisualStyleBackColor = true;
            this.btnMaxmin.Visible = false;
            this.btnMaxmin.Click += new System.EventHandler(this.btnMaxmin_Click);
            // 
            // btnMin
            // 
            this.btnMin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMin.FlatAppearance.BorderSize = 0;
            this.btnMin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMin.Image = ((System.Drawing.Image)(resources.GetObject("btnMin.Image")));
            this.btnMin.Location = new System.Drawing.Point(686, 408);
            this.btnMin.Name = "btnMin";
            this.btnMin.Size = new System.Drawing.Size(30, 30);
            this.btnMin.TabIndex = 2;
            this.btnMin.UseVisualStyleBackColor = true;
            this.btnMin.Visible = false;
            this.btnMin.Click += new System.EventHandler(this.btnMin_Click);
            // 
            // pbDraw
            // 
            this.pbDraw.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pbDraw.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbDraw.Location = new System.Drawing.Point(388, 2);
            this.pbDraw.Name = "pbDraw";
            this.pbDraw.Size = new System.Drawing.Size(400, 400);
            this.pbDraw.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbDraw.TabIndex = 3;
            this.pbDraw.TabStop = false;
            this.pbDraw.Visible = false;
            // 
            // btnCircle
            // 
            this.btnCircle.FlatAppearance.BorderSize = 0;
            this.btnCircle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCircle.Image = ((System.Drawing.Image)(resources.GetObject("btnCircle.Image")));
            this.btnCircle.Location = new System.Drawing.Point(12, 12);
            this.btnCircle.Name = "btnCircle";
            this.btnCircle.Size = new System.Drawing.Size(50, 50);
            this.btnCircle.TabIndex = 4;
            this.btnCircle.UseVisualStyleBackColor = true;
            this.btnCircle.Visible = false;
            this.btnCircle.Click += new System.EventHandler(this.btnCircle_Click);
            // 
            // btnIsotri
            // 
            this.btnIsotri.FlatAppearance.BorderSize = 0;
            this.btnIsotri.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIsotri.Image = ((System.Drawing.Image)(resources.GetObject("btnIsotri.Image")));
            this.btnIsotri.Location = new System.Drawing.Point(12, 68);
            this.btnIsotri.Name = "btnIsotri";
            this.btnIsotri.Size = new System.Drawing.Size(50, 100);
            this.btnIsotri.TabIndex = 5;
            this.btnIsotri.UseVisualStyleBackColor = true;
            this.btnIsotri.Visible = false;
            this.btnIsotri.Click += new System.EventHandler(this.btnIsotri_Click);
            // 
            // btnRhomb
            // 
            this.btnRhomb.FlatAppearance.BorderSize = 0;
            this.btnRhomb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRhomb.Image = ((System.Drawing.Image)(resources.GetObject("btnRhomb.Image")));
            this.btnRhomb.Location = new System.Drawing.Point(12, 174);
            this.btnRhomb.Name = "btnRhomb";
            this.btnRhomb.Size = new System.Drawing.Size(50, 50);
            this.btnRhomb.TabIndex = 6;
            this.btnRhomb.UseVisualStyleBackColor = true;
            this.btnRhomb.Visible = false;
            this.btnRhomb.Click += new System.EventHandler(this.btnRhomb_Click);
            // 
            // btnRighttri
            // 
            this.btnRighttri.FlatAppearance.BorderSize = 0;
            this.btnRighttri.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRighttri.Image = ((System.Drawing.Image)(resources.GetObject("btnRighttri.Image")));
            this.btnRighttri.Location = new System.Drawing.Point(12, 230);
            this.btnRighttri.Name = "btnRighttri";
            this.btnRighttri.Size = new System.Drawing.Size(50, 50);
            this.btnRighttri.TabIndex = 7;
            this.btnRighttri.UseVisualStyleBackColor = true;
            this.btnRighttri.Visible = false;
            this.btnRighttri.Click += new System.EventHandler(this.btnRighttri_Click);
            // 
            // btnEllipse
            // 
            this.btnEllipse.FlatAppearance.BorderSize = 0;
            this.btnEllipse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEllipse.Image = ((System.Drawing.Image)(resources.GetObject("btnEllipse.Image")));
            this.btnEllipse.Location = new System.Drawing.Point(12, 286);
            this.btnEllipse.Name = "btnEllipse";
            this.btnEllipse.Size = new System.Drawing.Size(100, 50);
            this.btnEllipse.TabIndex = 8;
            this.btnEllipse.UseVisualStyleBackColor = true;
            this.btnEllipse.Visible = false;
            this.btnEllipse.Click += new System.EventHandler(this.btnEllipse_Click);
            // 
            // btnSquare
            // 
            this.btnSquare.FlatAppearance.BorderSize = 0;
            this.btnSquare.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSquare.Image = ((System.Drawing.Image)(resources.GetObject("btnSquare.Image")));
            this.btnSquare.Location = new System.Drawing.Point(12, 342);
            this.btnSquare.Name = "btnSquare";
            this.btnSquare.Size = new System.Drawing.Size(50, 50);
            this.btnSquare.TabIndex = 9;
            this.btnSquare.UseVisualStyleBackColor = true;
            this.btnSquare.Visible = false;
            this.btnSquare.Click += new System.EventHandler(this.btnSquare_Click);
            // 
            // btnParallel
            // 
            this.btnParallel.FlatAppearance.BorderSize = 0;
            this.btnParallel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnParallel.Image = global::Task2.Properties.Resources.Параллелограмм;
            this.btnParallel.Location = new System.Drawing.Point(167, 12);
            this.btnParallel.Name = "btnParallel";
            this.btnParallel.Size = new System.Drawing.Size(50, 50);
            this.btnParallel.TabIndex = 10;
            this.btnParallel.UseVisualStyleBackColor = true;
            this.btnParallel.Visible = false;
            this.btnParallel.Click += new System.EventHandler(this.btnParallel_Click);
            // 
            // btnAim
            // 
            this.btnAim.FlatAppearance.BorderSize = 0;
            this.btnAim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAim.Image = global::Task2.Properties.Resources.Прицел;
            this.btnAim.Location = new System.Drawing.Point(167, 68);
            this.btnAim.Name = "btnAim";
            this.btnAim.Size = new System.Drawing.Size(50, 50);
            this.btnAim.TabIndex = 11;
            this.btnAim.UseVisualStyleBackColor = true;
            this.btnAim.Visible = false;
            this.btnAim.Click += new System.EventHandler(this.btnAim_Click);
            // 
            // btnEquiltri
            // 
            this.btnEquiltri.FlatAppearance.BorderSize = 0;
            this.btnEquiltri.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEquiltri.Image = global::Task2.Properties.Resources.равносторонний_треугольник;
            this.btnEquiltri.Location = new System.Drawing.Point(167, 180);
            this.btnEquiltri.Name = "btnEquiltri";
            this.btnEquiltri.Size = new System.Drawing.Size(50, 50);
            this.btnEquiltri.TabIndex = 12;
            this.btnEquiltri.UseVisualStyleBackColor = true;
            this.btnEquiltri.Visible = false;
            this.btnEquiltri.Click += new System.EventHandler(this.btnEquiltri_Click);
            // 
            // btnRectangle
            // 
            this.btnRectangle.FlatAppearance.BorderSize = 0;
            this.btnRectangle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRectangle.Image = global::Task2.Properties.Resources.Прямоугольник;
            this.btnRectangle.Location = new System.Drawing.Point(167, 236);
            this.btnRectangle.Name = "btnRectangle";
            this.btnRectangle.Size = new System.Drawing.Size(100, 50);
            this.btnRectangle.TabIndex = 13;
            this.btnRectangle.UseVisualStyleBackColor = true;
            this.btnRectangle.Visible = false;
            this.btnRectangle.Click += new System.EventHandler(this.btnRectangle_Click);
            // 
            // btnRing
            // 
            this.btnRing.FlatAppearance.BorderSize = 0;
            this.btnRing.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRing.Image = global::Task2.Properties.Resources.Окружность;
            this.btnRing.Location = new System.Drawing.Point(167, 292);
            this.btnRing.Name = "btnRing";
            this.btnRing.Size = new System.Drawing.Size(50, 50);
            this.btnRing.TabIndex = 14;
            this.btnRing.UseVisualStyleBackColor = true;
            this.btnRing.Visible = false;
            this.btnRing.Click += new System.EventHandler(this.btnRing_Click);
            // 
            // btnTrapezoid
            // 
            this.btnTrapezoid.FlatAppearance.BorderSize = 0;
            this.btnTrapezoid.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTrapezoid.Image = global::Task2.Properties.Resources.Трапеция;
            this.btnTrapezoid.Location = new System.Drawing.Point(167, 124);
            this.btnTrapezoid.Name = "btnTrapezoid";
            this.btnTrapezoid.Size = new System.Drawing.Size(50, 50);
            this.btnTrapezoid.TabIndex = 15;
            this.btnTrapezoid.UseVisualStyleBackColor = true;
            this.btnTrapezoid.Visible = false;
            this.btnTrapezoid.Click += new System.EventHandler(this.btnTrapezoid_Click);
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.ForestGreen;
            this.btnStart.Location = new System.Drawing.Point(276, 186);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(228, 23);
            this.btnStart.TabIndex = 16;
            this.btnStart.Text = "Начало работы с приложением";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.btnTrapezoid);
            this.Controls.Add(this.btnRing);
            this.Controls.Add(this.btnRectangle);
            this.Controls.Add(this.btnEquiltri);
            this.Controls.Add(this.btnAim);
            this.Controls.Add(this.btnParallel);
            this.Controls.Add(this.btnSquare);
            this.Controls.Add(this.btnEllipse);
            this.Controls.Add(this.btnRighttri);
            this.Controls.Add(this.btnRhomb);
            this.Controls.Add(this.btnIsotri);
            this.Controls.Add(this.btnCircle);
            this.Controls.Add(this.pbDraw);
            this.Controls.Add(this.btnMin);
            this.Controls.Add(this.btnMaxmin);
            this.Controls.Add(this.btnClose);
            this.Name = "frmMain";
            this.Text = "Задание №2 выполнил: Панаргин Владислав Максимович; Номер варианта: 5; Дата выпол" +
    "нения: 03/03/2024";
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbDraw)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnMaxmin;
        private System.Windows.Forms.Button btnMin;
        private System.Windows.Forms.PictureBox pbDraw;
        private System.Windows.Forms.Button btnCircle;
        private System.Windows.Forms.Button btnIsotri;
        private System.Windows.Forms.Button btnRhomb;
        private System.Windows.Forms.Button btnRighttri;
        private System.Windows.Forms.Button btnEllipse;
        private System.Windows.Forms.Button btnSquare;
        private System.Windows.Forms.Button btnParallel;
        private System.Windows.Forms.Button btnAim;
        private System.Windows.Forms.Button btnEquiltri;
        private System.Windows.Forms.Button btnRectangle;
        private System.Windows.Forms.Button btnRing;
        private System.Windows.Forms.Button btnTrapezoid;
        private System.Windows.Forms.Button btnStart;
    }
}

