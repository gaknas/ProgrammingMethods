﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Task2
{
    public partial class frmHelp : Form
    {
        public frmHelp()
        {
            InitializeComponent();
        }

        private void frmHelp_Load(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader("E:\\Методы программирования\\Задание 2\\Task2\\HelpInformation.txt");
            string info = sr.ReadToEnd();
            lblHelp.Text = info;
            sr.Close();
        }
    }
}
