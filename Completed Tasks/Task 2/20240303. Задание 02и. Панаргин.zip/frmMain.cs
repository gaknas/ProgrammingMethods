﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task2
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            frmHelp f1 = new frmHelp();
            f1.Show(this);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMaxmin_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void btnMin_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnCircle_Click(object sender, EventArgs e)
        {
            Bitmap bitmap = new Bitmap(400, 400, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
            Graphics graphics = Graphics.FromImage(bitmap);
            SolidBrush brush = new SolidBrush(Color.Red);
            graphics.FillEllipse(brush, new Rectangle(100, 100, 200, 200));
            pbDraw.Image = (Image)bitmap;
        }

        private void btnIsotri_Click(object sender, EventArgs e)
        {
            Bitmap bitmap = new Bitmap(400, 400, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
            Graphics graphics = Graphics.FromImage(bitmap);
            Pen pen = new Pen(Color.Red, 3);
            graphics.DrawPolygon(pen, new PointF[3] {new PointF(200, 100), new PointF(150, 300), new PointF(250, 300)});
            pbDraw.Image = (Image)bitmap;
        }

        private void btnRhomb_Click(object sender, EventArgs e)
        {
            Bitmap bitmap = new Bitmap(400, 400, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
            Graphics graphics = Graphics.FromImage(bitmap);
            Pen pen = new Pen(Color.Red, 3);
            graphics.DrawPolygon(pen, new PointF[4] { new PointF(200, 100), new PointF(150, 200), new PointF(200, 300), new PointF(250, 200)});
            pbDraw.Image = (Image)bitmap;
        }

        private void btnRighttri_Click(object sender, EventArgs e)
        {
            Bitmap bitmap = new Bitmap(400, 400, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
            Graphics graphics = Graphics.FromImage(bitmap);
            Pen pen = new Pen(Color.Red, 3);
            graphics.DrawPolygon(pen, new PointF[3] { new PointF(100, 100), new PointF(100, 300), new PointF(300, 300) });
            pbDraw.Image = (Image)bitmap;
        }

        private void btnEllipse_Click(object sender, EventArgs e)
        {
            Bitmap bitmap = new Bitmap(400, 400, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
            Graphics graphics = Graphics.FromImage(bitmap);
            Pen pen = new Pen(Color.Red, 3);
            graphics.DrawEllipse(pen, 150, 100, 100, 200);
            pbDraw.Image = (Image)bitmap;
        }

        private void btnSquare_Click(object sender, EventArgs e)
        {
            Bitmap bitmap = new Bitmap(400, 400, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
            Graphics graphics = Graphics.FromImage(bitmap);
            Pen pen = new Pen(Color.Red, 3);
            graphics.DrawPolygon(pen, new PointF[4] { new PointF(100, 100), new PointF(100, 300), new PointF(300, 300), new PointF(300, 100) });
            pbDraw.Image = (Image)bitmap;
        }

        private void btnParallel_Click(object sender, EventArgs e)
        {
            Bitmap bitmap = new Bitmap(400, 400, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
            Graphics graphics = Graphics.FromImage(bitmap);
            Pen pen = new Pen(Color.Red, 3);
            graphics.DrawPolygon(pen, new PointF[4] { new PointF(150, 150), new PointF(100, 250), new PointF(250, 250), new PointF(300, 150) });
            pbDraw.Image = (Image)bitmap;
        }

        private void btnTrapezoid_Click(object sender, EventArgs e)
        {
            Bitmap bitmap = new Bitmap(400, 400, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
            Graphics graphics = Graphics.FromImage(bitmap);
            Pen pen = new Pen(Color.Red, 3);
            graphics.DrawPolygon(pen, new PointF[4] { new PointF(150, 150), new PointF(250, 150), new PointF(300, 250), new PointF(100, 250) });
            pbDraw.Image = (Image)bitmap;
        }

        private void btnAim_Click(object sender, EventArgs e)
        {
            Bitmap bitmap = new Bitmap(400, 400, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
            Graphics graphics = Graphics.FromImage(bitmap);
            Pen pen = new Pen(Color.Red, 2);
            graphics.DrawEllipse(pen, new Rectangle(100, 100, 200, 200));
            graphics.DrawEllipse(pen, new Rectangle(150, 150, 100, 100));
            graphics.DrawLine(pen, 200, 100, 200, 300);
            graphics.DrawLine(pen, 100, 200, 300, 200);
            SolidBrush brush = new SolidBrush(Color.Red);
            graphics.FillEllipse(brush, new Rectangle(195, 195, 10, 10));
            pbDraw.Image = (Image)bitmap;
        }

        private void btnEquiltri_Click(object sender, EventArgs e)
        {
            Bitmap bitmap = new Bitmap(400, 400, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
            Graphics graphics = Graphics.FromImage(bitmap);
            Pen pen = new Pen(Color.Red, 3);
            graphics.DrawPolygon(pen, new PointF[3] { new PointF(200, 300-100*(float)Math.Sqrt(3)), new PointF(100, 300), new PointF(300, 300) });
            pbDraw.Image = (Image)bitmap;
        }

        private void btnRectangle_Click(object sender, EventArgs e)
        {
            Bitmap bitmap = new Bitmap(400, 400, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
            Graphics graphics = Graphics.FromImage(bitmap);
            Pen pen = new Pen(Color.Red, 3);
            graphics.DrawPolygon(pen, new PointF[4] { new PointF(100, 150), new PointF(100, 250), new PointF(300, 250), new PointF(300, 150) });
            pbDraw.Image = (Image)bitmap;
        }

        private void btnRing_Click(object sender, EventArgs e)
        {
            Bitmap bitmap = new Bitmap(400, 400, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
            Graphics graphics = Graphics.FromImage(bitmap);
            Pen pen = new Pen(Color.Red, 3);
            graphics.DrawEllipse(pen, new Rectangle(100, 100, 200, 200));
            pbDraw.Image = (Image)bitmap;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            foreach (Control control in this.Controls)
            {
                control.Visible = true;
            }
            btnStart.Visible = false;
        }
    }
}
