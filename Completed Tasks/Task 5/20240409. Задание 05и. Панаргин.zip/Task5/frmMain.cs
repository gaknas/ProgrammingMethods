﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Word = Microsoft.Office.Interop.Word;

namespace Task5
{
    public partial class frmMain : Form
    {
        private Word.Application wordapp;
        private Word.Document wd;
        public frmMain()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.cbActType.SelectedIndex = 0;
            this.cbDocType.SelectedIndex = 0;
            this.cbNum.SelectedIndex = 0;
            this.cbSpacing.SelectedIndex = 0;
            this.LoadInfo();
        }

        private float getSpacing(object arg)
        {
            switch (arg)
            {
                case "Разреженный":
                    return 1;
                case "Уплотненный":
                    return -1;
                default:
                    return 0;
            }
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            wordapp = new Word.Application();
            wd = wordapp.Documents.Add();
            StreamReader sr = new StreamReader(Application.StartupPath + "\\TextInfo.txt");
            string temp;
            string[] atemp;
            wd.Content.Font.Size = 14;
            wd.Content.Font.Color = 0;
            wd.Content.Font.Name = "Times New Roman";
            wd.Content.Font.Spacing = this.getSpacing(this.cbSpacing.SelectedItem);
            while ((temp = sr.ReadLine()) != null)
            {
                atemp = temp.Split(';');
                wordapp.Selection.Font.Name = atemp[2];
                wordapp.Selection.Font.Size = int.Parse(atemp[3]);
                wordapp.Selection.ParagraphFormat.Alignment = (Word.WdParagraphAlignment)int.Parse(atemp[4]);
                wordapp.Selection.TypeText(atemp[0]);
                if (atemp[1] == "1")
                {
                    wordapp.Selection.TypeParagraph();
                }
            }
            wordapp.Selection.HomeKey(Word.WdUnits.wdStory, Word.WdMovementType.wdMove);
            wordapp.Selection.MoveDown(Word.WdUnits.wdParagraph, 4, Word.WdMovementType.wdMove);
            wordapp.Selection.ParagraphFormat.TabStops.Add(wordapp.CentimetersToPoints(16.5f), Word.WdAlignmentTabAlignment.wdRight, Word.WdTabLeader.wdTabLeaderLines);
            wordapp.Selection.TypeText("\t");
            wordapp.Selection.TypeParagraph();
            sr.Close();
            //wp.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceMultiple;
            //wp.LineSpacing = wordapp.LinesToPoints(3);
            wd.SaveAs2(Application.StartupPath + "\\TST.doc");
            wordapp.Quit();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            this.SaveInfo();
        }
        private void btnPrint_Click(object sender, EventArgs e)
        {
            frmPrint fp = new frmPrint();
            fp.Show();
        }
        private void LoadInfo()
        {
            StreamReader sr = new StreamReader(Application.StartupPath + "\\TextInfo.txt");
            string[] args = sr.ReadLine().Split(';');
            this.txtMinstr.Text = args[0].Trim();
            this.cbFMn.SelectedItem = args[2];
            this.nupMn.Value = decimal.Parse(args[3]);
            this.cbAMn.SelectedIndex = int.Parse(args[4]);
            args = sr.ReadLine().Split(';');
            this.txtRegalia.Text = args[0].Trim();
            this.cbFRe.SelectedItem = args[2];
            this.nupRe.Value = decimal.Parse(args[3]);
            this.cbARe.SelectedIndex = int.Parse(args[4]);
            args = sr.ReadLine().Split(';');
            this.txtUni.Text = args[0].Trim();
            this.cbFUn.SelectedItem = args[2];
            this.nupUn.Value = decimal.Parse(args[3]);
            this.cbAUn.SelectedIndex = int.Parse(args[4]);
            args = sr.ReadLine().Split(';');
            this.txtInst.Text = args[0].Trim();
            this.cbFIn.SelectedItem = args[2];
            this.nupIn.Value = decimal.Parse(args[3]);
            this.cbAIn.SelectedIndex = int.Parse(args[4]);
            args = sr.ReadLine().Split(';');
            this.txtDep.Text = args[0].Trim();
            this.cbFDe.SelectedItem = args[2];
            this.nupDe.Value = decimal.Parse(args[3]);
            this.cbADe.SelectedIndex = int.Parse(args[4]);
            args = sr.ReadLine().Split(';');
            this.cbDocType.Text = args[0].Trim();
            this.cbFDt.SelectedItem = args[2];
            this.nupDt.Value = decimal.Parse(args[3]);
            this.cbADt.SelectedIndex = int.Parse(args[4]);
            args = sr.ReadLine().Split(';');
            this.txtLinkpo.Text = args[0].Trim();
            this.cbFLi.SelectedItem = args[2];
            this.nupLi.Value = decimal.Parse(args[3]);
            this.cbALi.SelectedIndex = int.Parse(args[4]);
            args = sr.ReadLine().Split(';');
            this.cbActType.Text = args[0].Trim();
            this.cbFAt.SelectedItem = args[2];
            this.nupAt.Value = decimal.Parse(args[3]);
            this.cbAAt.SelectedIndex = int.Parse(args[4]);
            args = sr.ReadLine().Split(';');
            this.cbNum.Text = args[0].Trim();
            this.cbFNu.SelectedItem = args[2];
            this.nupNu.Value = decimal.Parse(args[3]);
            this.cbANu.SelectedIndex = int.Parse(args[4]);
            args = sr.ReadLine().Split(';');
            this.txtName.Text = args[0].Trim();
            this.cbFNa.SelectedItem = args[2];
            this.nupNa.Value = decimal.Parse(args[3]);
            this.cbANa.SelectedIndex = int.Parse(args[4]);
            args = sr.ReadLine().Split(';');
            this.txtLinkSubj.Text = args[0].Trim();
            this.cbFSl.SelectedItem = args[2];
            this.nupSl.Value = decimal.Parse(args[3]);
            this.cbASl.SelectedIndex = int.Parse(args[4]);
            args = sr.ReadLine().Split(';');
            this.txtSubjName.Text = args[0].Trim();
            this.cbFSu.SelectedItem = args[2];
            this.nupSu.Value = decimal.Parse(args[3]);
            this.cbASu.SelectedIndex = int.Parse(args[4]);
            args = sr.ReadLine().Split(';');
            this.txtGroup.Text = args[0].Trim();
            this.cbFGr.SelectedItem = args[2];
            this.nupGr.Value = decimal.Parse(args[3]);
            this.cbAGr.SelectedIndex = int.Parse(args[4]);
            args = sr.ReadLine().Split(';');
            this.txtFio.Text = args[0].Trim();
            this.cbFFi.SelectedItem = args[2];
            this.nupFi.Value = decimal.Parse(args[3]);
            this.cbAFi.SelectedIndex = int.Parse(args[4]);
            args = sr.ReadLine().Split(';');
            this.txtInsp.Text = args[0].Trim();
            this.cbFIns.SelectedItem = args[2];
            this.nupIns.Value = decimal.Parse(args[3]);
            this.cbAIns.SelectedIndex = int.Parse(args[4]);
            args = sr.ReadLine().Split(';');
            this.txtCity.Text = args[0].Trim();
            this.cbFCi.SelectedItem = args[2];
            this.nupCi.Value = decimal.Parse(args[3]);
            this.cbACi.SelectedIndex = int.Parse(args[4]);
            sr.Close();
        }

        private void SaveInfo()
        {
            StreamWriter sw = new StreamWriter(Application.StartupPath + "\\TextInfo.txt");
            sw.WriteLine(this.txtMinstr.Text+";1;"+this.cbFMn.SelectedItem+";"+this.nupMn.Value+";"+this.cbAMn.SelectedIndex);
            sw.WriteLine(this.txtRegalia.Text + ";1;" + this.cbFRe.SelectedItem + ";" + this.nupRe.Value + ";" + this.cbARe.SelectedIndex);
            sw.WriteLine(this.txtUni.Text + ";1;" + this.cbFUn.SelectedItem + ";" + this.nupUn.Value + ";" + this.cbAUn.SelectedIndex);
            sw.WriteLine(this.txtInst.Text + ";1;" + this.cbFIn.SelectedItem + ";" + this.nupIn.Value + ";" + this.cbAIn.SelectedIndex);
            sw.WriteLine(this.txtDep.Text + ";1;" + this.cbFDe.SelectedItem + ";" + this.nupDe.Value + ";" + this.cbADe.SelectedIndex);
            sw.WriteLine(this.cbDocType.Text + ";0;" + this.cbFDt.SelectedItem + ";" + this.nupDt.Value + ";" + this.cbADt.SelectedIndex);
            sw.WriteLine(" " + this.txtLinkpo.Text + ";0;" + this.cbFLi.SelectedItem + ";" + this.nupLi.Value + ";" + this.cbALi.SelectedIndex);
            sw.WriteLine(" " + this.cbActType.Text + ";0;" + this.cbFAt.SelectedItem + ";" + this.nupAt.Value + ";" + this.cbAAt.SelectedIndex);
            sw.WriteLine(" " + this.cbNum.Text + ";1;" + this.cbFNu.SelectedItem + ";" + this.nupNu.Value + ";" + this.cbANu.SelectedIndex);
            sw.WriteLine(this.txtName.Text + ";1;" + this.cbFNa.SelectedItem + ";" + this.nupNa.Value + ";" + this.cbANa.SelectedIndex);
            sw.WriteLine(this.txtLinkSubj.Text + ";0;" + this.cbFSl.SelectedItem + ";" + this.nupSl.Value + ";" + this.cbASl.SelectedIndex);
            sw.WriteLine(" " + this.txtSubjName.Text + ";1;" + this.cbFSu.SelectedItem + ";" + this.nupSu.Value + ";" + this.cbASu.SelectedIndex);
            sw.WriteLine(this.txtGroup.Text + ";1;" + this.cbFGr.SelectedItem + ";" + this.nupGr.Value + ";" + this.cbAGr.SelectedIndex);
            sw.WriteLine(this.txtFio.Text + ";1;" + this.cbFFi.SelectedItem + ";" + this.nupFi.Value + ";" + this.cbAFi.SelectedIndex);
            sw.WriteLine(this.txtInsp.Text + ";1;" + this.cbFIns.SelectedItem + ";" + this.nupIns.Value + ";" + this.cbAIns.SelectedIndex);
            sw.Write(this.txtCity.Text + ";1;" + this.cbFCi.SelectedItem + ";" + this.nupCi.Value + ";" + this.cbACi.SelectedIndex);
            sw.Close();
        }

        private void btnAnk_Click(object sender, EventArgs e)
        {
            frmAnk fa = new frmAnk();
            fa.Show();
        }
    }
}
