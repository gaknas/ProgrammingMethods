﻿
namespace Task5
{
    partial class frmMain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMinstr = new System.Windows.Forms.TextBox();
            this.txtRegalia = new System.Windows.Forms.TextBox();
            this.txtUni = new System.Windows.Forms.TextBox();
            this.txtInst = new System.Windows.Forms.TextBox();
            this.txtDep = new System.Windows.Forms.TextBox();
            this.txtLinkpo = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtLinkSubj = new System.Windows.Forms.TextBox();
            this.txtSubjName = new System.Windows.Forms.TextBox();
            this.txtGroup = new System.Windows.Forms.TextBox();
            this.txtFio = new System.Windows.Forms.TextBox();
            this.txtInsp = new System.Windows.Forms.TextBox();
            this.cbDocType = new System.Windows.Forms.ComboBox();
            this.cbActType = new System.Windows.Forms.ComboBox();
            this.cbNum = new System.Windows.Forms.ComboBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.btnCreate = new System.Windows.Forms.Button();
            this.cbFMn = new System.Windows.Forms.ComboBox();
            this.nupMn = new System.Windows.Forms.NumericUpDown();
            this.cbAMn = new System.Windows.Forms.ComboBox();
            this.cbFRe = new System.Windows.Forms.ComboBox();
            this.nupRe = new System.Windows.Forms.NumericUpDown();
            this.cbFUn = new System.Windows.Forms.ComboBox();
            this.cbFIn = new System.Windows.Forms.ComboBox();
            this.cbFDe = new System.Windows.Forms.ComboBox();
            this.cbFDt = new System.Windows.Forms.ComboBox();
            this.cbFLi = new System.Windows.Forms.ComboBox();
            this.cbFAt = new System.Windows.Forms.ComboBox();
            this.cbFNu = new System.Windows.Forms.ComboBox();
            this.cbFNa = new System.Windows.Forms.ComboBox();
            this.cbFSl = new System.Windows.Forms.ComboBox();
            this.cbFSu = new System.Windows.Forms.ComboBox();
            this.cbFGr = new System.Windows.Forms.ComboBox();
            this.cbFFi = new System.Windows.Forms.ComboBox();
            this.cbFIns = new System.Windows.Forms.ComboBox();
            this.cbFCi = new System.Windows.Forms.ComboBox();
            this.nupIn = new System.Windows.Forms.NumericUpDown();
            this.nupUn = new System.Windows.Forms.NumericUpDown();
            this.nupAt = new System.Windows.Forms.NumericUpDown();
            this.nupLi = new System.Windows.Forms.NumericUpDown();
            this.nupDt = new System.Windows.Forms.NumericUpDown();
            this.nupDe = new System.Windows.Forms.NumericUpDown();
            this.nupSu = new System.Windows.Forms.NumericUpDown();
            this.nupSl = new System.Windows.Forms.NumericUpDown();
            this.nupNa = new System.Windows.Forms.NumericUpDown();
            this.nupNu = new System.Windows.Forms.NumericUpDown();
            this.nupGr = new System.Windows.Forms.NumericUpDown();
            this.nupFi = new System.Windows.Forms.NumericUpDown();
            this.nupIns = new System.Windows.Forms.NumericUpDown();
            this.nupCi = new System.Windows.Forms.NumericUpDown();
            this.cbARe = new System.Windows.Forms.ComboBox();
            this.cbAIn = new System.Windows.Forms.ComboBox();
            this.cbAUn = new System.Windows.Forms.ComboBox();
            this.cbAAt = new System.Windows.Forms.ComboBox();
            this.cbALi = new System.Windows.Forms.ComboBox();
            this.cbADt = new System.Windows.Forms.ComboBox();
            this.cbADe = new System.Windows.Forms.ComboBox();
            this.cbASu = new System.Windows.Forms.ComboBox();
            this.cbASl = new System.Windows.Forms.ComboBox();
            this.cbANa = new System.Windows.Forms.ComboBox();
            this.cbANu = new System.Windows.Forms.ComboBox();
            this.cbACi = new System.Windows.Forms.ComboBox();
            this.cbAIns = new System.Windows.Forms.ComboBox();
            this.cbAFi = new System.Windows.Forms.ComboBox();
            this.cbAGr = new System.Windows.Forms.ComboBox();
            this.cbSpacing = new System.Windows.Forms.ComboBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnAnk = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nupMn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupRe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupIn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupUn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupAt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupLi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupDt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupDe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupSu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupSl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupNa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupNu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupGr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupFi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupIns)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupCi)).BeginInit();
            this.SuspendLayout();
            // 
            // txtMinstr
            // 
            this.txtMinstr.Location = new System.Drawing.Point(12, 12);
            this.txtMinstr.Name = "txtMinstr";
            this.txtMinstr.Size = new System.Drawing.Size(504, 20);
            this.txtMinstr.TabIndex = 0;
            this.txtMinstr.Text = "Министерство транспорта Российской Федерации";
            // 
            // txtRegalia
            // 
            this.txtRegalia.Location = new System.Drawing.Point(12, 38);
            this.txtRegalia.Name = "txtRegalia";
            this.txtRegalia.Size = new System.Drawing.Size(504, 20);
            this.txtRegalia.TabIndex = 1;
            this.txtRegalia.Text = "Федеральное государственное автономное образовательное учреждение высшего образов" +
    "ания";
            // 
            // txtUni
            // 
            this.txtUni.Location = new System.Drawing.Point(12, 64);
            this.txtUni.Name = "txtUni";
            this.txtUni.Size = new System.Drawing.Size(504, 20);
            this.txtUni.TabIndex = 2;
            this.txtUni.Text = "«Российский университет транспорта» (РУТ (МИИТ))";
            // 
            // txtInst
            // 
            this.txtInst.Location = new System.Drawing.Point(12, 90);
            this.txtInst.Name = "txtInst";
            this.txtInst.Size = new System.Drawing.Size(504, 20);
            this.txtInst.TabIndex = 3;
            this.txtInst.Text = "Институт транспортной техники и систем управления";
            // 
            // txtDep
            // 
            this.txtDep.Location = new System.Drawing.Point(12, 116);
            this.txtDep.Name = "txtDep";
            this.txtDep.Size = new System.Drawing.Size(504, 20);
            this.txtDep.TabIndex = 4;
            this.txtDep.Text = "Кафедра «Управление и защита информации»";
            // 
            // txtLinkpo
            // 
            this.txtLinkpo.Location = new System.Drawing.Point(12, 168);
            this.txtLinkpo.Name = "txtLinkpo";
            this.txtLinkpo.Size = new System.Drawing.Size(504, 20);
            this.txtLinkpo.TabIndex = 6;
            this.txtLinkpo.Text = "по";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(12, 246);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(504, 20);
            this.txtName.TabIndex = 9;
            this.txtName.Text = "Наименование работы";
            // 
            // txtLinkSubj
            // 
            this.txtLinkSubj.Location = new System.Drawing.Point(12, 272);
            this.txtLinkSubj.Name = "txtLinkSubj";
            this.txtLinkSubj.Size = new System.Drawing.Size(504, 20);
            this.txtLinkSubj.TabIndex = 10;
            this.txtLinkSubj.Text = "по дисциплине";
            // 
            // txtSubjName
            // 
            this.txtSubjName.Location = new System.Drawing.Point(12, 298);
            this.txtSubjName.Name = "txtSubjName";
            this.txtSubjName.Size = new System.Drawing.Size(504, 20);
            this.txtSubjName.TabIndex = 11;
            this.txtSubjName.Text = "Наименование дисциплины";
            // 
            // txtGroup
            // 
            this.txtGroup.Location = new System.Drawing.Point(12, 324);
            this.txtGroup.Name = "txtGroup";
            this.txtGroup.Size = new System.Drawing.Size(504, 20);
            this.txtGroup.TabIndex = 12;
            this.txtGroup.Text = "Выполнил: ст. гр. ТКИ-341";
            // 
            // txtFio
            // 
            this.txtFio.Location = new System.Drawing.Point(12, 350);
            this.txtFio.Name = "txtFio";
            this.txtFio.Size = new System.Drawing.Size(504, 20);
            this.txtFio.TabIndex = 13;
            this.txtFio.Text = "Панаргин Владислав Максимович";
            // 
            // txtInsp
            // 
            this.txtInsp.Location = new System.Drawing.Point(12, 376);
            this.txtInsp.Name = "txtInsp";
            this.txtInsp.Size = new System.Drawing.Size(504, 20);
            this.txtInsp.TabIndex = 14;
            this.txtInsp.Text = "Проверил: доцент, к.т.н. Сафронов Антон Игоревич";
            // 
            // cbDocType
            // 
            this.cbDocType.FormattingEnabled = true;
            this.cbDocType.Items.AddRange(new object[] {
            "отчёт",
            "реферат",
            "эссе",
            "курсовой проект",
            "курсовая работа",
            "доклад",
            "домашнее задание"});
            this.cbDocType.Location = new System.Drawing.Point(12, 141);
            this.cbDocType.Name = "cbDocType";
            this.cbDocType.Size = new System.Drawing.Size(504, 21);
            this.cbDocType.TabIndex = 15;
            // 
            // cbActType
            // 
            this.cbActType.FormattingEnabled = true;
            this.cbActType.Items.AddRange(new object[] {
            "лабораторной работе",
            "практической работе",
            "индивидуальному заданию",
            "учебной практике",
            "производственной практике",
            "преддипломной практике"});
            this.cbActType.Location = new System.Drawing.Point(12, 193);
            this.cbActType.Name = "cbActType";
            this.cbActType.Size = new System.Drawing.Size(504, 21);
            this.cbActType.TabIndex = 16;
            // 
            // cbNum
            // 
            this.cbNum.FormattingEnabled = true;
            this.cbNum.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cbNum.Location = new System.Drawing.Point(12, 219);
            this.cbNum.Name = "cbNum";
            this.cbNum.Size = new System.Drawing.Size(504, 21);
            this.cbNum.TabIndex = 17;
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(12, 402);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(504, 20);
            this.txtCity.TabIndex = 18;
            this.txtCity.Text = "Москва - 2024";
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(861, 39);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(95, 23);
            this.btnCreate.TabIndex = 19;
            this.btnCreate.Text = "Создать";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // cbFMn
            // 
            this.cbFMn.FormattingEnabled = true;
            this.cbFMn.Items.AddRange(new object[] {
            "Times New Roman",
            "Arial"});
            this.cbFMn.Location = new System.Drawing.Point(522, 10);
            this.cbFMn.Name = "cbFMn";
            this.cbFMn.Size = new System.Drawing.Size(121, 21);
            this.cbFMn.TabIndex = 20;
            // 
            // nupMn
            // 
            this.nupMn.Location = new System.Drawing.Point(649, 10);
            this.nupMn.Name = "nupMn";
            this.nupMn.Size = new System.Drawing.Size(39, 20);
            this.nupMn.TabIndex = 21;
            // 
            // cbAMn
            // 
            this.cbAMn.FormattingEnabled = true;
            this.cbAMn.Items.AddRange(new object[] {
            "Left",
            "Center",
            "Right"});
            this.cbAMn.Location = new System.Drawing.Point(694, 10);
            this.cbAMn.Name = "cbAMn";
            this.cbAMn.Size = new System.Drawing.Size(121, 21);
            this.cbAMn.TabIndex = 22;
            // 
            // cbFRe
            // 
            this.cbFRe.FormattingEnabled = true;
            this.cbFRe.Items.AddRange(new object[] {
            "Times New Roman",
            "Arial"});
            this.cbFRe.Location = new System.Drawing.Point(522, 37);
            this.cbFRe.Name = "cbFRe";
            this.cbFRe.Size = new System.Drawing.Size(121, 21);
            this.cbFRe.TabIndex = 23;
            // 
            // nupRe
            // 
            this.nupRe.Location = new System.Drawing.Point(649, 36);
            this.nupRe.Name = "nupRe";
            this.nupRe.Size = new System.Drawing.Size(39, 20);
            this.nupRe.TabIndex = 24;
            // 
            // cbFUn
            // 
            this.cbFUn.FormattingEnabled = true;
            this.cbFUn.Items.AddRange(new object[] {
            "Times New Roman",
            "Arial"});
            this.cbFUn.Location = new System.Drawing.Point(522, 64);
            this.cbFUn.Name = "cbFUn";
            this.cbFUn.Size = new System.Drawing.Size(121, 21);
            this.cbFUn.TabIndex = 26;
            // 
            // cbFIn
            // 
            this.cbFIn.FormattingEnabled = true;
            this.cbFIn.Items.AddRange(new object[] {
            "Times New Roman",
            "Arial"});
            this.cbFIn.Location = new System.Drawing.Point(522, 89);
            this.cbFIn.Name = "cbFIn";
            this.cbFIn.Size = new System.Drawing.Size(121, 21);
            this.cbFIn.TabIndex = 27;
            // 
            // cbFDe
            // 
            this.cbFDe.FormattingEnabled = true;
            this.cbFDe.Items.AddRange(new object[] {
            "Times New Roman",
            "Arial"});
            this.cbFDe.Location = new System.Drawing.Point(522, 116);
            this.cbFDe.Name = "cbFDe";
            this.cbFDe.Size = new System.Drawing.Size(121, 21);
            this.cbFDe.TabIndex = 28;
            // 
            // cbFDt
            // 
            this.cbFDt.FormattingEnabled = true;
            this.cbFDt.Items.AddRange(new object[] {
            "Times New Roman",
            "Arial"});
            this.cbFDt.Location = new System.Drawing.Point(522, 141);
            this.cbFDt.Name = "cbFDt";
            this.cbFDt.Size = new System.Drawing.Size(121, 21);
            this.cbFDt.TabIndex = 29;
            // 
            // cbFLi
            // 
            this.cbFLi.FormattingEnabled = true;
            this.cbFLi.Items.AddRange(new object[] {
            "Times New Roman",
            "Arial"});
            this.cbFLi.Location = new System.Drawing.Point(522, 166);
            this.cbFLi.Name = "cbFLi";
            this.cbFLi.Size = new System.Drawing.Size(121, 21);
            this.cbFLi.TabIndex = 30;
            // 
            // cbFAt
            // 
            this.cbFAt.FormattingEnabled = true;
            this.cbFAt.Items.AddRange(new object[] {
            "Times New Roman",
            "Arial"});
            this.cbFAt.Location = new System.Drawing.Point(522, 193);
            this.cbFAt.Name = "cbFAt";
            this.cbFAt.Size = new System.Drawing.Size(121, 21);
            this.cbFAt.TabIndex = 31;
            // 
            // cbFNu
            // 
            this.cbFNu.FormattingEnabled = true;
            this.cbFNu.Items.AddRange(new object[] {
            "Times New Roman",
            "Arial"});
            this.cbFNu.Location = new System.Drawing.Point(522, 219);
            this.cbFNu.Name = "cbFNu";
            this.cbFNu.Size = new System.Drawing.Size(121, 21);
            this.cbFNu.TabIndex = 32;
            // 
            // cbFNa
            // 
            this.cbFNa.FormattingEnabled = true;
            this.cbFNa.Items.AddRange(new object[] {
            "Times New Roman",
            "Arial"});
            this.cbFNa.Location = new System.Drawing.Point(522, 245);
            this.cbFNa.Name = "cbFNa";
            this.cbFNa.Size = new System.Drawing.Size(121, 21);
            this.cbFNa.TabIndex = 33;
            // 
            // cbFSl
            // 
            this.cbFSl.FormattingEnabled = true;
            this.cbFSl.Items.AddRange(new object[] {
            "Times New Roman",
            "Arial"});
            this.cbFSl.Location = new System.Drawing.Point(522, 271);
            this.cbFSl.Name = "cbFSl";
            this.cbFSl.Size = new System.Drawing.Size(121, 21);
            this.cbFSl.TabIndex = 34;
            // 
            // cbFSu
            // 
            this.cbFSu.FormattingEnabled = true;
            this.cbFSu.Items.AddRange(new object[] {
            "Times New Roman",
            "Arial"});
            this.cbFSu.Location = new System.Drawing.Point(522, 297);
            this.cbFSu.Name = "cbFSu";
            this.cbFSu.Size = new System.Drawing.Size(121, 21);
            this.cbFSu.TabIndex = 35;
            // 
            // cbFGr
            // 
            this.cbFGr.FormattingEnabled = true;
            this.cbFGr.Items.AddRange(new object[] {
            "Times New Roman",
            "Arial"});
            this.cbFGr.Location = new System.Drawing.Point(522, 323);
            this.cbFGr.Name = "cbFGr";
            this.cbFGr.Size = new System.Drawing.Size(121, 21);
            this.cbFGr.TabIndex = 36;
            // 
            // cbFFi
            // 
            this.cbFFi.FormattingEnabled = true;
            this.cbFFi.Items.AddRange(new object[] {
            "Times New Roman",
            "Arial"});
            this.cbFFi.Location = new System.Drawing.Point(522, 349);
            this.cbFFi.Name = "cbFFi";
            this.cbFFi.Size = new System.Drawing.Size(121, 21);
            this.cbFFi.TabIndex = 37;
            // 
            // cbFIns
            // 
            this.cbFIns.FormattingEnabled = true;
            this.cbFIns.Items.AddRange(new object[] {
            "Times New Roman",
            "Arial"});
            this.cbFIns.Location = new System.Drawing.Point(522, 375);
            this.cbFIns.Name = "cbFIns";
            this.cbFIns.Size = new System.Drawing.Size(121, 21);
            this.cbFIns.TabIndex = 38;
            // 
            // cbFCi
            // 
            this.cbFCi.FormattingEnabled = true;
            this.cbFCi.Items.AddRange(new object[] {
            "Times New Roman",
            "Arial"});
            this.cbFCi.Location = new System.Drawing.Point(522, 402);
            this.cbFCi.Name = "cbFCi";
            this.cbFCi.Size = new System.Drawing.Size(121, 21);
            this.cbFCi.TabIndex = 39;
            // 
            // nupIn
            // 
            this.nupIn.Location = new System.Drawing.Point(649, 91);
            this.nupIn.Name = "nupIn";
            this.nupIn.Size = new System.Drawing.Size(39, 20);
            this.nupIn.TabIndex = 55;
            // 
            // nupUn
            // 
            this.nupUn.Location = new System.Drawing.Point(649, 65);
            this.nupUn.Name = "nupUn";
            this.nupUn.Size = new System.Drawing.Size(39, 20);
            this.nupUn.TabIndex = 54;
            // 
            // nupAt
            // 
            this.nupAt.Location = new System.Drawing.Point(649, 197);
            this.nupAt.Name = "nupAt";
            this.nupAt.Size = new System.Drawing.Size(39, 20);
            this.nupAt.TabIndex = 59;
            // 
            // nupLi
            // 
            this.nupLi.Location = new System.Drawing.Point(649, 166);
            this.nupLi.Name = "nupLi";
            this.nupLi.Size = new System.Drawing.Size(39, 20);
            this.nupLi.TabIndex = 58;
            // 
            // nupDt
            // 
            this.nupDt.Location = new System.Drawing.Point(649, 142);
            this.nupDt.Name = "nupDt";
            this.nupDt.Size = new System.Drawing.Size(39, 20);
            this.nupDt.TabIndex = 57;
            // 
            // nupDe
            // 
            this.nupDe.Location = new System.Drawing.Point(649, 116);
            this.nupDe.Name = "nupDe";
            this.nupDe.Size = new System.Drawing.Size(39, 20);
            this.nupDe.TabIndex = 56;
            // 
            // nupSu
            // 
            this.nupSu.Location = new System.Drawing.Point(649, 301);
            this.nupSu.Name = "nupSu";
            this.nupSu.Size = new System.Drawing.Size(39, 20);
            this.nupSu.TabIndex = 63;
            // 
            // nupSl
            // 
            this.nupSl.Location = new System.Drawing.Point(649, 275);
            this.nupSl.Name = "nupSl";
            this.nupSl.Size = new System.Drawing.Size(39, 20);
            this.nupSl.TabIndex = 62;
            // 
            // nupNa
            // 
            this.nupNa.Location = new System.Drawing.Point(649, 246);
            this.nupNa.Name = "nupNa";
            this.nupNa.Size = new System.Drawing.Size(39, 20);
            this.nupNa.TabIndex = 61;
            // 
            // nupNu
            // 
            this.nupNu.Location = new System.Drawing.Point(649, 220);
            this.nupNu.Name = "nupNu";
            this.nupNu.Size = new System.Drawing.Size(39, 20);
            this.nupNu.TabIndex = 60;
            // 
            // nupGr
            // 
            this.nupGr.Location = new System.Drawing.Point(649, 323);
            this.nupGr.Name = "nupGr";
            this.nupGr.Size = new System.Drawing.Size(39, 20);
            this.nupGr.TabIndex = 64;
            // 
            // nupFi
            // 
            this.nupFi.Location = new System.Drawing.Point(649, 349);
            this.nupFi.Name = "nupFi";
            this.nupFi.Size = new System.Drawing.Size(39, 20);
            this.nupFi.TabIndex = 65;
            // 
            // nupIns
            // 
            this.nupIns.Location = new System.Drawing.Point(649, 377);
            this.nupIns.Name = "nupIns";
            this.nupIns.Size = new System.Drawing.Size(39, 20);
            this.nupIns.TabIndex = 66;
            // 
            // nupCi
            // 
            this.nupCi.Location = new System.Drawing.Point(649, 402);
            this.nupCi.Name = "nupCi";
            this.nupCi.Size = new System.Drawing.Size(39, 20);
            this.nupCi.TabIndex = 67;
            // 
            // cbARe
            // 
            this.cbARe.FormattingEnabled = true;
            this.cbARe.Items.AddRange(new object[] {
            "Left",
            "Center",
            "Right"});
            this.cbARe.Location = new System.Drawing.Point(694, 35);
            this.cbARe.Name = "cbARe";
            this.cbARe.Size = new System.Drawing.Size(121, 21);
            this.cbARe.TabIndex = 68;
            // 
            // cbAIn
            // 
            this.cbAIn.FormattingEnabled = true;
            this.cbAIn.Items.AddRange(new object[] {
            "Left",
            "Center",
            "Right"});
            this.cbAIn.Location = new System.Drawing.Point(694, 89);
            this.cbAIn.Name = "cbAIn";
            this.cbAIn.Size = new System.Drawing.Size(121, 21);
            this.cbAIn.TabIndex = 70;
            // 
            // cbAUn
            // 
            this.cbAUn.FormattingEnabled = true;
            this.cbAUn.Items.AddRange(new object[] {
            "Left",
            "Center",
            "Right"});
            this.cbAUn.Location = new System.Drawing.Point(694, 65);
            this.cbAUn.Name = "cbAUn";
            this.cbAUn.Size = new System.Drawing.Size(121, 21);
            this.cbAUn.TabIndex = 69;
            // 
            // cbAAt
            // 
            this.cbAAt.FormattingEnabled = true;
            this.cbAAt.Items.AddRange(new object[] {
            "Left",
            "Center",
            "Right"});
            this.cbAAt.Location = new System.Drawing.Point(694, 195);
            this.cbAAt.Name = "cbAAt";
            this.cbAAt.Size = new System.Drawing.Size(121, 21);
            this.cbAAt.TabIndex = 74;
            // 
            // cbALi
            // 
            this.cbALi.FormattingEnabled = true;
            this.cbALi.Items.AddRange(new object[] {
            "Left",
            "Center",
            "Right"});
            this.cbALi.Location = new System.Drawing.Point(694, 166);
            this.cbALi.Name = "cbALi";
            this.cbALi.Size = new System.Drawing.Size(121, 21);
            this.cbALi.TabIndex = 73;
            // 
            // cbADt
            // 
            this.cbADt.FormattingEnabled = true;
            this.cbADt.Items.AddRange(new object[] {
            "Left",
            "Center",
            "Right"});
            this.cbADt.Location = new System.Drawing.Point(694, 140);
            this.cbADt.Name = "cbADt";
            this.cbADt.Size = new System.Drawing.Size(121, 21);
            this.cbADt.TabIndex = 72;
            // 
            // cbADe
            // 
            this.cbADe.FormattingEnabled = true;
            this.cbADe.Items.AddRange(new object[] {
            "Left",
            "Center",
            "Right"});
            this.cbADe.Location = new System.Drawing.Point(694, 115);
            this.cbADe.Name = "cbADe";
            this.cbADe.Size = new System.Drawing.Size(121, 21);
            this.cbADe.TabIndex = 71;
            // 
            // cbASu
            // 
            this.cbASu.FormattingEnabled = true;
            this.cbASu.Items.AddRange(new object[] {
            "Left",
            "Center",
            "Right"});
            this.cbASu.Location = new System.Drawing.Point(694, 298);
            this.cbASu.Name = "cbASu";
            this.cbASu.Size = new System.Drawing.Size(121, 21);
            this.cbASu.TabIndex = 78;
            // 
            // cbASl
            // 
            this.cbASl.FormattingEnabled = true;
            this.cbASl.Items.AddRange(new object[] {
            "Left",
            "Center",
            "Right"});
            this.cbASl.Location = new System.Drawing.Point(694, 274);
            this.cbASl.Name = "cbASl";
            this.cbASl.Size = new System.Drawing.Size(121, 21);
            this.cbASl.TabIndex = 77;
            // 
            // cbANa
            // 
            this.cbANa.FormattingEnabled = true;
            this.cbANa.Items.AddRange(new object[] {
            "Left",
            "Center",
            "Right"});
            this.cbANa.Location = new System.Drawing.Point(694, 247);
            this.cbANa.Name = "cbANa";
            this.cbANa.Size = new System.Drawing.Size(121, 21);
            this.cbANa.TabIndex = 76;
            // 
            // cbANu
            // 
            this.cbANu.FormattingEnabled = true;
            this.cbANu.Items.AddRange(new object[] {
            "Left",
            "Center",
            "Right"});
            this.cbANu.Location = new System.Drawing.Point(694, 222);
            this.cbANu.Name = "cbANu";
            this.cbANu.Size = new System.Drawing.Size(121, 21);
            this.cbANu.TabIndex = 75;
            // 
            // cbACi
            // 
            this.cbACi.FormattingEnabled = true;
            this.cbACi.Items.AddRange(new object[] {
            "Left",
            "Center",
            "Right"});
            this.cbACi.Location = new System.Drawing.Point(694, 402);
            this.cbACi.Name = "cbACi";
            this.cbACi.Size = new System.Drawing.Size(121, 21);
            this.cbACi.TabIndex = 82;
            // 
            // cbAIns
            // 
            this.cbAIns.FormattingEnabled = true;
            this.cbAIns.Items.AddRange(new object[] {
            "Left",
            "Center",
            "Right"});
            this.cbAIns.Location = new System.Drawing.Point(694, 377);
            this.cbAIns.Name = "cbAIns";
            this.cbAIns.Size = new System.Drawing.Size(121, 21);
            this.cbAIns.TabIndex = 81;
            // 
            // cbAFi
            // 
            this.cbAFi.FormattingEnabled = true;
            this.cbAFi.Items.AddRange(new object[] {
            "Left",
            "Center",
            "Right"});
            this.cbAFi.Location = new System.Drawing.Point(694, 347);
            this.cbAFi.Name = "cbAFi";
            this.cbAFi.Size = new System.Drawing.Size(121, 21);
            this.cbAFi.TabIndex = 80;
            // 
            // cbAGr
            // 
            this.cbAGr.FormattingEnabled = true;
            this.cbAGr.Items.AddRange(new object[] {
            "Left",
            "Center",
            "Right"});
            this.cbAGr.Location = new System.Drawing.Point(694, 324);
            this.cbAGr.Name = "cbAGr";
            this.cbAGr.Size = new System.Drawing.Size(121, 21);
            this.cbAGr.TabIndex = 79;
            // 
            // cbSpacing
            // 
            this.cbSpacing.FormattingEnabled = true;
            this.cbSpacing.Items.AddRange(new object[] {
            "Обычный",
            "Разреженный",
            "Уплотненный"});
            this.cbSpacing.Location = new System.Drawing.Point(861, 12);
            this.cbSpacing.Name = "cbSpacing";
            this.cbSpacing.Size = new System.Drawing.Size(121, 21);
            this.cbSpacing.TabIndex = 83;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(861, 68);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(95, 23);
            this.btnSave.TabIndex = 84;
            this.btnSave.Text = "Сохранить";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Location = new System.Drawing.Point(861, 97);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(95, 23);
            this.btnPrint.TabIndex = 85;
            this.btnPrint.Text = "Предпросмотр";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnAnk
            // 
            this.btnAnk.Location = new System.Drawing.Point(861, 126);
            this.btnAnk.Name = "btnAnk";
            this.btnAnk.Size = new System.Drawing.Size(95, 23);
            this.btnAnk.TabIndex = 86;
            this.btnAnk.Text = "Анкета";
            this.btnAnk.UseVisualStyleBackColor = true;
            this.btnAnk.Click += new System.EventHandler(this.btnAnk_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1032, 431);
            this.Controls.Add(this.btnAnk);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.cbSpacing);
            this.Controls.Add(this.cbACi);
            this.Controls.Add(this.cbAIns);
            this.Controls.Add(this.cbAFi);
            this.Controls.Add(this.cbAGr);
            this.Controls.Add(this.cbASu);
            this.Controls.Add(this.cbASl);
            this.Controls.Add(this.cbANa);
            this.Controls.Add(this.cbANu);
            this.Controls.Add(this.cbAAt);
            this.Controls.Add(this.cbALi);
            this.Controls.Add(this.cbADt);
            this.Controls.Add(this.cbADe);
            this.Controls.Add(this.cbAIn);
            this.Controls.Add(this.cbAUn);
            this.Controls.Add(this.cbARe);
            this.Controls.Add(this.nupCi);
            this.Controls.Add(this.nupIns);
            this.Controls.Add(this.nupFi);
            this.Controls.Add(this.nupGr);
            this.Controls.Add(this.nupSu);
            this.Controls.Add(this.nupSl);
            this.Controls.Add(this.nupNa);
            this.Controls.Add(this.nupNu);
            this.Controls.Add(this.nupAt);
            this.Controls.Add(this.nupLi);
            this.Controls.Add(this.nupDt);
            this.Controls.Add(this.nupDe);
            this.Controls.Add(this.nupIn);
            this.Controls.Add(this.nupUn);
            this.Controls.Add(this.cbFCi);
            this.Controls.Add(this.cbFIns);
            this.Controls.Add(this.cbFFi);
            this.Controls.Add(this.cbFGr);
            this.Controls.Add(this.cbFSu);
            this.Controls.Add(this.cbFSl);
            this.Controls.Add(this.cbFNa);
            this.Controls.Add(this.cbFNu);
            this.Controls.Add(this.cbFAt);
            this.Controls.Add(this.cbFLi);
            this.Controls.Add(this.cbFDt);
            this.Controls.Add(this.cbFDe);
            this.Controls.Add(this.cbFIn);
            this.Controls.Add(this.cbFUn);
            this.Controls.Add(this.nupRe);
            this.Controls.Add(this.cbFRe);
            this.Controls.Add(this.cbAMn);
            this.Controls.Add(this.nupMn);
            this.Controls.Add(this.cbFMn);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.cbNum);
            this.Controls.Add(this.cbActType);
            this.Controls.Add(this.cbDocType);
            this.Controls.Add(this.txtInsp);
            this.Controls.Add(this.txtFio);
            this.Controls.Add(this.txtGroup);
            this.Controls.Add(this.txtSubjName);
            this.Controls.Add(this.txtLinkSubj);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.txtLinkpo);
            this.Controls.Add(this.txtDep);
            this.Controls.Add(this.txtInst);
            this.Controls.Add(this.txtUni);
            this.Controls.Add(this.txtRegalia);
            this.Controls.Add(this.txtMinstr);
            this.Name = "frmMain";
            this.Text = "«Задание №5 выполнил: Панаргин В.М.; Номер варианта: 5; Дата выполнения: 09/04/20" +
    "24";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nupMn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupRe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupIn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupUn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupAt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupLi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupDt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupDe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupSu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupSl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupNa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupNu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupGr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupFi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupIns)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupCi)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMinstr;
        private System.Windows.Forms.TextBox txtRegalia;
        private System.Windows.Forms.TextBox txtUni;
        private System.Windows.Forms.TextBox txtInst;
        private System.Windows.Forms.TextBox txtDep;
        private System.Windows.Forms.TextBox txtLinkpo;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtLinkSubj;
        private System.Windows.Forms.TextBox txtSubjName;
        private System.Windows.Forms.TextBox txtGroup;
        private System.Windows.Forms.TextBox txtFio;
        private System.Windows.Forms.TextBox txtInsp;
        private System.Windows.Forms.ComboBox cbDocType;
        private System.Windows.Forms.ComboBox cbActType;
        private System.Windows.Forms.ComboBox cbNum;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.ComboBox cbFMn;
        private System.Windows.Forms.NumericUpDown nupMn;
        private System.Windows.Forms.ComboBox cbAMn;
        private System.Windows.Forms.ComboBox cbFRe;
        private System.Windows.Forms.NumericUpDown nupRe;
        private System.Windows.Forms.ComboBox cbFUn;
        private System.Windows.Forms.ComboBox cbFIn;
        private System.Windows.Forms.ComboBox cbFDe;
        private System.Windows.Forms.ComboBox cbFDt;
        private System.Windows.Forms.ComboBox cbFLi;
        private System.Windows.Forms.ComboBox cbFAt;
        private System.Windows.Forms.ComboBox cbFNu;
        private System.Windows.Forms.ComboBox cbFNa;
        private System.Windows.Forms.ComboBox cbFSl;
        private System.Windows.Forms.ComboBox cbFSu;
        private System.Windows.Forms.ComboBox cbFGr;
        private System.Windows.Forms.ComboBox cbFFi;
        private System.Windows.Forms.ComboBox cbFIns;
        private System.Windows.Forms.ComboBox cbFCi;
        private System.Windows.Forms.NumericUpDown nupIn;
        private System.Windows.Forms.NumericUpDown nupUn;
        private System.Windows.Forms.NumericUpDown nupAt;
        private System.Windows.Forms.NumericUpDown nupLi;
        private System.Windows.Forms.NumericUpDown nupDt;
        private System.Windows.Forms.NumericUpDown nupDe;
        private System.Windows.Forms.NumericUpDown nupSu;
        private System.Windows.Forms.NumericUpDown nupSl;
        private System.Windows.Forms.NumericUpDown nupNa;
        private System.Windows.Forms.NumericUpDown nupNu;
        private System.Windows.Forms.NumericUpDown nupGr;
        private System.Windows.Forms.NumericUpDown nupFi;
        private System.Windows.Forms.NumericUpDown nupIns;
        private System.Windows.Forms.NumericUpDown nupCi;
        private System.Windows.Forms.ComboBox cbARe;
        private System.Windows.Forms.ComboBox cbAIn;
        private System.Windows.Forms.ComboBox cbAUn;
        private System.Windows.Forms.ComboBox cbAAt;
        private System.Windows.Forms.ComboBox cbALi;
        private System.Windows.Forms.ComboBox cbADt;
        private System.Windows.Forms.ComboBox cbADe;
        private System.Windows.Forms.ComboBox cbASu;
        private System.Windows.Forms.ComboBox cbASl;
        private System.Windows.Forms.ComboBox cbANa;
        private System.Windows.Forms.ComboBox cbANu;
        private System.Windows.Forms.ComboBox cbACi;
        private System.Windows.Forms.ComboBox cbAIns;
        private System.Windows.Forms.ComboBox cbAFi;
        private System.Windows.Forms.ComboBox cbAGr;
        private System.Windows.Forms.ComboBox cbSpacing;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnAnk;
    }
}

