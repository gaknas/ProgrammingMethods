﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Task5
{
    public partial class frmPrint : Form
    {
        public frmPrint()
        {
            InitializeComponent();
        }

        private void frmPrint_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            this.pbPrint.Paint += PbPrint_Paint;

        }

        private void PbPrint_Paint(object sender, PaintEventArgs e)
        {
            Brush br = Brushes.Black;
            StringFormat sf = new StringFormat();
            StreamReader sr = new StreamReader(Application.StartupPath + "\\TextInfo.txt");
            string temp;
            string[] atemp;
            string buffer = "";
            int vert_marg = 0;
            int hor_marg = 0;
            while ((temp = sr.ReadLine()) != null)
            {
                atemp = temp.Split(';');
                buffer += atemp[0];
                if (atemp[1] == "1")
                {
                    sf.Alignment = (StringAlignment)int.Parse(atemp[4]);
                    e.Graphics.DrawString(buffer, new Font(atemp[2], int.Parse(atemp[3])), br, new RectangleF(hor_marg, vert_marg, 1920, 20), sf);
                    buffer = "";
                    vert_marg +=20;
                }
            }
            sr.Close();
        }
    }
}
