﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;

namespace Task5
{
    public partial class frmAnk : Form
    {
        private Word.Application wordapp;
        private Word.Document wd;
        private Word.Bookmark wb;
        public frmAnk()
        {
            InitializeComponent();
        }

        private void frmAnk_Load(object sender, EventArgs e)
        {
            
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            wordapp = new Word.Application();
            wd = wordapp.Documents.Add(Application.StartupPath + "\\template.doc");
            int counter = 22;
            foreach (Control control in this.Controls)
            {
                if (!Control.Equals(control, this.btnCreate))
                {
                    wb = wd.Bookmarks[counter];
                    wordapp.Selection.HomeKey(Word.WdUnits.wdStory, Word.WdMovementType.wdMove);
                    wordapp.Selection.Move(Word.WdUnits.wdCharacter, wb.Start);
                    wordapp.Selection.TypeText(control.Text);
                    counter -= 1;
                }

            }
            wd.SaveAs2(Application.StartupPath + "\\anketa.doc");
            wordapp.Quit();
        }
    }
}
