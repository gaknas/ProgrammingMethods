﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Task_3
{
    public partial class frmHelp : Form
    {
        private TextBox txtHelp;
        public frmHelp()
        {
            this.txtHelp = new TextBox();
            this.SuspendLayout();
            //
            // txtHelp
            //
            this.txtHelp.Location = new System.Drawing.Point(0, 0);
            this.txtHelp.Size = new System.Drawing.Size(800, 450);
            this.txtHelp.Multiline = true;
            this.txtHelp.ReadOnly = true;
            // 
            // frmHelp
            // 
            this.ClientSize = new System.Drawing.Size(800, 100);
            this.Controls.Add(this.txtHelp);
            this.Name = "frmHelp";
            this.Text = "Окно со справочной информацией";
            this.Cursor = Cursors.Hand;
            this.Load += new System.EventHandler(this.frmHelp_Load);
            this.ResumeLayout(false);
        }

        private void frmHelp_Load(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader("E:\\Методы программирования\\Задание 3\\Task3\\HelpInformation.txt");
            txtHelp.Text = sr.ReadToEnd();
            sr.Close();
            this.Resize += FrmHelp_Resize;
        }

        private void FrmHelp_Resize(object sender, EventArgs e)
        {
            this.txtHelp.Size = this.ClientSize;
        }
    }
}
