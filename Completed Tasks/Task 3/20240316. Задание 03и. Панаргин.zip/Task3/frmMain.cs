﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Task_3
{
    public partial class frmMain : Form
    {
        private ListBox lstFunctions;
        private ListBox lstX;
        private ListBox lstY;
        private NumericUpDown nudStart;
        private NumericUpDown nudEnd;
        private NumericUpDown nudStep;
        private Button btnCalc;
        private Button btnStart;
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            this.Text = "Задание №3 выполнил: Панаргин Владислав Максимович; Номер варианта: 5; Дата выполнения: 17/03/2024";
            this.Cursor = Cursors.Hand;
            this.BackColor = SystemColors.ControlText;
            this.ClientSize = new Size(400, 310);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.lstFunctions = new ListBox();
            this.lstX = new ListBox();
            this.lstY = new ListBox();
            this.nudStart = new NumericUpDown();
            this.nudEnd = new NumericUpDown();
            this.nudStep = new NumericUpDown();
            this.btnCalc = new Button();
            this.btnStart = new Button();

            //lstFunctions
            this.lstFunctions.Location = new System.Drawing.Point(10,10);
            this.lstFunctions.Size = new System.Drawing.Size(160,170);
            this.lstFunctions.Items.AddRange(new string[] { "Извлечение корня", "Секанс", "Возведение в квадрат", "Арктангенс", "Косинус", "Арккосинус", "Тангенс", "Арксинус", "Синус", "Десятичный логарифм", "Натуральный логарифм", "Логарифм по основанию 2" });
            this.lstFunctions.SelectedIndexChanged += LstFunctions_SelectedIndexChanged;
            this.lstFunctions.SelectedIndex = 0;

            //lstX
            this.lstX.Location = new Point(180, 10);
            this.lstX.Size = new Size(100, 300);
            this.lstX.SelectedIndexChanged += LstX_SelectedIndexChanged;

            //lstY
            this.lstY.Location = new Point(290, 10);
            this.lstY.Size = new Size(100, 300);
            this.lstY.SelectedIndexChanged += LstY_SelectedIndexChanged;

            //nudStart
            this.nudStart.Location = new Point(10, 190);
            this.nudStart.Size = new Size(50, 20);
            this.nudStart.Minimum = -100;
            this.nudStart.Maximum = 100;
            this.nudStart.Value = -5;
            this.nudStart.DecimalPlaces = 1;
            this.nudStart.Increment = (decimal)0.1;

            //nudEnd
            this.nudEnd.Location = new Point(65, 190);
            this.nudEnd.Size = new Size(50, 20);
            this.nudEnd.Minimum = -100;
            this.nudEnd.Maximum = 100;
            this.nudEnd.Value = 5;
            this.nudEnd.DecimalPlaces = 1;
            this.nudEnd.Increment = (decimal)0.1;

            //nudStep
            this.nudStep.Location = new Point(120, 190);
            this.nudStep.Size = new Size(50, 20);
            this.nudStep.Minimum = (decimal)0.1 ;
            this.nudStep.Maximum = 10;
            this.nudStep.Value = (decimal)0.1;
            this.nudStep.DecimalPlaces = 1;
            this.nudStep.Increment = (decimal)0.1;

            //btnCalc
            this.btnCalc.Location = new Point(10, 220);
            this.btnCalc.Size = new Size(160, 80);
            this.btnCalc.FlatStyle = FlatStyle.Flat;
            this.btnCalc.FlatAppearance.BorderSize = 1;
            this.btnCalc.Text = "Рассчитать";
            this.btnCalc.Click += BtnCalc_Click;

            //btnStart
            this.btnStart.Location = new Point(100, 135);
            this.btnStart.Size = new Size(200, 40);
            this.btnStart.FlatStyle = FlatStyle.Flat;
            this.btnStart.FlatAppearance.BorderSize = 1;
            this.btnStart.Text = "Начало работы с приложением";
            this.btnStart.Click += BtnStart_Click;

            this.Controls.AddRange(new Control[] { lstFunctions, lstX, lstY, nudStart, nudEnd, nudStep, btnCalc });
            foreach (Control control in this.Controls)
            {
                control.Visible = false;
            }
            this.Controls.Add(btnStart);
            foreach (Control control in this.Controls)
            {
                control.BackColor = SystemColors.ControlText;
                control.ForeColor = SystemColors.Window;
            }
            frmHelp fh = new frmHelp();
            fh.Owner = this;
            fh.ShowDialog();
            fh.Dispose();
        }

        private void BtnStart_Click(object sender, EventArgs e)
        {
            foreach (Control control in this.Controls)
            {
                control.Visible = true;
            }
            this.btnStart.Visible = false;
        }

        private void LstY_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.lstX.SelectedIndex = this.lstY.SelectedIndex;
        }

        private void LstX_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.lstY.SelectedIndex = this.lstX.SelectedIndex;
        }

        private void BtnCalc_Click(object sender, EventArgs e)
        {
            this.UpdateFile();
            this.lstX.Items.Clear();
            this.lstY.Items.Clear();
            StreamReader sr = new StreamReader("E:\\Методы программирования\\Задание 3\\Task3\\FuncArgs.txt");
            while (true)
            {
                string str = sr.ReadLine();
                if (str == null) break;
                string[] strarr = str.Split('{');
                this.lstX.Items.Add(strarr[0]);
                this.lstY.Items.Add(strarr[1]);
            }
            sr.Close();
        }

        private void LstFunctions_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.UpdateFile();
        }

        private void UpdateFile()
        {
            StreamWriter sw = new StreamWriter("E:\\Методы программирования\\Задание 3\\Task3\\FuncArgs.txt");
            decimal start = this.nudStart.Value;
            decimal end = this.nudEnd.Value;
            decimal step = this.nudStep.Value;
            for (decimal i = start; i < end; i+=step)
            {
                sw.Write(i);
                sw.Write("{");
                sw.Write(this.Calc(i));
                sw.Write("\n");
            }
            sw.Write(end);
            sw.Write("{");
            sw.Write(this.Calc(end));
            sw.Close();
        }

        private string Calc(decimal arg)
        {
            switch (this.lstFunctions.SelectedIndex)
            {
                case 0:
                    if (arg >= 0) return Math.Sqrt((double)arg).ToString("F1");
                    else return "UNDEFINED";
                case 1:
                    if (Math.Cos((double)arg) != 0) return (1 / Math.Cos((double)arg)).ToString("F1");
                    else return "UNDEFINED";
                case 2:
                    return Math.Pow((double)arg, 2).ToString("F1");
                case 3:
                    return Math.Atan((double)arg).ToString("F1");
                case 4:
                    return Math.Cos((double)arg).ToString("F1");
                case 5:
                    if (Math.Abs(arg) > 1) return "UNDEFINED";
                    else return Math.Acos((double)arg).ToString("F1");
                case 6:
                    if (Math.Cos((double)arg) != 0) return Math.Tan((double)arg).ToString("F1");
                    else return "UNDEFINED";
                case 7:
                    if (Math.Abs(arg) > 1) return "UNDEFINED";
                    else return Math.Asin((double)arg).ToString("F1");
                case 8:
                    return Math.Sin((double)arg).ToString("F1");
                case 9:
                    if (arg > 0) return Math.Log((double)arg, 10).ToString("F1");
                    else return "UNDEFINED";
                case 10:
                    if (arg > 0) return Math.Log((double)arg, Math.E).ToString("F1");
                    else return "UNDEFINED";
                default:
                    if (arg > 0) return Math.Log((double)arg, 2).ToString("F1");
                    else return "UNDEFINED";
            }
        }
    }
}
